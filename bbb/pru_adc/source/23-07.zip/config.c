#include <stdint.h>
#include <pru_cfg.h>

// Config
extern void config_IEP(void);
extern void config_INTC(void);
extern void config_ADC(void);
/********************************************/

// Função:    config
// Descrição: Configura periféricos
// Entrada:   -
// Saída:     -
/*********************************************************************************/
void config(void)
{
CT_CFG.SYSCFG_bit.STANDBY_INIT = 0;             // Habilita a master port OCP (On Chip Peripheral)
config_ADC();                                   // Configura o módulo ADC
config_IEP();                                   // Configura TIMER IEP
config_INTC();                                  // Configura INTC da PRU
}
/********************************************/
