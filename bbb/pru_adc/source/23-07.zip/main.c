// Máxima frequência de sample rate: 600 kHz
// Lendo e escrevendo em assembly em qualquer endereço do mapa de memória global, usando constant table e CONTROL_BUFFER
// Próximo: otimizar a função clear_flag_IEP (é o ultimo gargalo)

#include <stdint.h>
#include <stdlib.h>
#include <pru_cfg.h>
#include "rsc_table_pru1.h"
#include "adress_table.h"

#define PRU_READ        0xAA                    // Palavra de controle que habilita a leitura do PRU_BUFFER, por parte da PRU
#define ARM_READ        0xCC                    // Palavra de controle que habilita a leitura do ARM_BUFFER, por parte do ARM
#define LOCK            0xDD                    // Palavra de controle de travamento

#define CH1             1                       // Número de amostras a serem feitas do canal 1
#define CH3             2                       // Número de amostras a serem feitas do canal 3
#define PACK            4                       // Número de pacotes

// Escopo de funções

// Hardware
extern int button_state(void);
extern void debounce(void);
extern int led_read(void);
extern void led_write(int i);
extern void led_toggle(void);
/********************************************/

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
extern void bit_clear(int ADDR, int x);
extern void bit_set(int ADDR, int x);
extern void bit_write_interval(int ADDR, int MSB, int LSB, int content);
extern int bit_read(int ADDR, int x);
extern int bit_read_interval(int ADDR, int MSB, int LSB);
/********************************************/

// ADC
extern void config_ADC(void);
int* capture(int* chan, int n);
/********************************************/

// IEP
extern void set_wave_IEP(int freq, int duty);
extern void config_IEP(void);
extern void config_INTC(void);
extern int flag_IEP(void);
extern int flag_HOST(void);
extern void clear_flag_IEP(void);
/********************************************/

// Config
extern void config(void);
/********************************************/

// Assembly
extern void init(void);
extern void read(void);
extern void write(void);
/********************************************/

void main(void)
{
led_write(0);
memory(CONTROL_BUFFER,'w',FIFO1DATA,'k');               // Escreve o endereço de FIFO1DATA no CONTROL_BUFFER
memory(CONTROL_BUFFER+4,'w',STEPENABLE,'k');            // Escreve o endereço de STEPENABLE no CONTROL_BUFFER
memory(CONTROL_BUFFER+8,'w',ARM_BUFFER,'k');            // Escreve o endereço de ARM_BUFFER no CONTROL_BUFFER
init();                                                 // Lê os endereços no CONTROL_BUFFER e armazena em r10, r11 e r12
config();                                               // Configura periféricos
while(1)
    {
    if(flag_HOST()&&flag_IEP())                         // Aguarda uma interrupção do HOST e Checa se a fonte de interrupção é de fato o timer IEP
        {
        led_toggle();
        read();                                         // Captura o resultado da conversão AD
        clear_flag_IEP();                               // Limpa os flags associados ao evento IEP_EVENT do TIMER IEP
        }
    write();                                            // Escreve o resultado da conversão no ARM_BUFFER
    }
}
