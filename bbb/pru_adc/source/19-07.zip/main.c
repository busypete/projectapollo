// Máxima frequência de sample rate: 341,6 kHz
// Código dividido em vários arquivos fonte
// Próximo: 'adress_table.h' contendo os defines das posições de memórias dos registradores
// Próximo: maneira mais rápida de ler o resultado da conversão AD (DMA)
// Próximo: maneira mais rápida de escrever o resultado da conversão AD para o ARM (UART, I2C, REMOTEPROC, etc)
// Próximo: mudar o overlay e colocar o mínimo de sample delay e open delay pra ver se muda algo (probably not, loaded on boot only)

#include <stdint.h>
#include <stdlib.h>
#include <pru_cfg.h>
#include "rsc_table_pru1.h"

#define PRU_ICSS        0x4A300000
#define PRU_BUFFER      PRU_ICSS + 0x00010000   // Frame de leitura do ponto de vista da PRU
#define ARM_BUFFER      PRU_ICSS + 0x00011000   // Frame de escrita do ponto de vista da PRU
#define CONTROL_BUFFER  PRU_ICSS + 0x00012000   // Frame de controle
#define PRU_READ        0xAA                    // Palavra de controle que habilita a leitura do PRU_BUFFER, por parte da PRU
#define ARM_READ        0xCC                    // Palavra de controle que habilita a leitura do ARM_BUFFER, por parte do ARM
#define LOCK            0xDD                    // Palavra de controle de travamento

#define CH1             1                       // Número de amostras a serem feitas do canal 1
#define CH3             2                       // Número de amostras a serem feitas do canal 3
#define PACK            4                       // Número de pacotes

#define ADC_TSC         0x44E0D000
#define STEPENABLE      (ADC_TSC + 0x54)
#define FIFO1DATA       (ADC_TSC + 0x200)

// Escopo de funções

// Hardware
extern int button_state(void);
extern void debounce(void);
extern int led_read(void);
extern void led_write(int i);
extern void led_toggle(void);
/********************************************/

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
extern void bit_clear(int ADDR, int x);
extern void bit_set(int ADDR, int x);
extern void bit_write_interval(int ADDR, int MSB, int LSB, int content);
extern int bit_read(int ADDR, int x);
extern int bit_read_interval(int ADDR, int MSB, int LSB);
/********************************************/

// ADC
extern void config_ADC(void);
int* capture(int* chan, int n);
/********************************************/

// IEP
extern void set_wave_IEP(int freq, int duty);
extern void config_IEP(void);
extern void config_INTC(void);
extern int flag_IEP(void);
extern int flag_HOST(void);
extern void clear_flag_IEP(void);
/********************************************/

// Config
extern void config(void);
/********************************************/

void main(void)
{
led_write(0);
config();                                               // Configura periféricos
int* chan1 = (int*)(malloc((CH1+1)*sizeof(int)));       // Aloca vetor para receber as amostras do canal 1
while(1)
    {
    if(flag_HOST())                                     // Aguarda uma interrupção do HOST
        {
        if(flag_IEP())                                  // Checa se a fonte de interrupção é de fato o timer IEP
            {
            led_toggle();
            clear_flag_IEP();                           // Limpa os flags associados ao evento IEP_EVENT do TIMER IEP
            chan1[0] = (memory(FIFO1DATA,'r',0x00,'o'))&(0xFFF); // Captura o resultado da conversão
            memory(ARM_BUFFER,'w',chan1[0],'k');        // Transmissão das amostras
            }
        }
    bit_set(STEPENABLE,1);                              // Reabilita canal
    }
}
