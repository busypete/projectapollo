// Mudanças devido ao novo overlay
// A PRU1 não possui mais nenhum botão ou led, pois todos os recursos foram drenadas pelo LCD ou eMMC
// O debug do SAMPLE_RATE é feito pela PRU0 no evento de EOF

#include <stdint.h>
#include <stdlib.h>
#include <pru_cfg.h>
#include "rsc_table_pru1.h"

// IEP
extern int flag_IEP(void);
extern int flag_HOST(void);
extern void clear_flag_IEP(void);
/********************************************/

// Config
extern void config(void);
/********************************************/

// Assembly
extern void sample(void);
extern void restart(void);
/********************************************/

void main(void)
{
config();                                               // Configura periféricos
while(1)
    {
    if(flag_HOST()&&flag_IEP())                         // Aguarda uma interrupção do HOST e checa se a fonte de interrupção é de fato o timer IEP
        {
        sample();                                       // Captura dos canais AIN0 e AIN7
        clear_flag_IEP();                               // Limpa os flags associados ao evento IEP_EVENT do TIMER IEP
        }
    restart();                                          // Restaura ponteiros de resultado às posições iniciais dos frames
    }
}
