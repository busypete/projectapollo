// Controle do frame
#define EOF                 0xAA                                    // Fim de frame
#define ENABLE              0x202                                   // Palavra de habilitação do STEP1 e STEP9 da FSM do ADC

// Parâmetros do scope
#define SAMPLE_RATE         300000                                  // Frequência de amostragem atual do sinal de entrada

// Dimensões do frame
#define SAMPLE_PER_PERIOD   12                                      // Número de amostras por período
#define PERIOD_PER_FRAME    10                                      // Número de períodos por frame (será uma função de TIME/DIV)
#define FRAME_SIZE          SAMPLE_PER_PERIOD*PERIOD_PER_FRAME      // Número de amostras por frame

