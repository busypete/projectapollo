// Controle do frame
#define EOF                 0xAA                                    // Fim de frame
#define ENABLE              0x202                                   // Palavra de habilitação do STEP1 e STEP9 da FSM do ADC

// Parâmetros do scope
#define SAMPLE_RATE         300000                                  // Frequência de amostragem atual do sinal de entrada

// Dimensões do frame
#define BUFFER_SIZE          960                                     // Número de amostras por frame

