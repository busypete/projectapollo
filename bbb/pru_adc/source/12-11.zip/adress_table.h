// PRU BUFFER
#define PRU_ICSS        0x4A300000
#define PRU0_BUFFER     (PRU_ICSS + 0x00000000)   // Frame genérico da RAM PRU0
#define PRU1_BUFFER     (PRU_ICSS + 0x00002000)   // Frame genérico da RAM PRU1
#define CONTROL_BUFFER  (PRU_ICSS + 0x00010000)   // Frame de controle (RAM compartilhada entre as PRU's)

// PRU IEP
#define PRU_IEP         (PRU_ICSS + 0x0002E000)
#define IEP_TMR_GLB_STS (PRU_IEP + 0x4)
#define IEP_TMR_CMP_STS (PRU_IEP + 0x44)

// PRU INTC
#define PRU_INTC        (PRU_ICSS + 0x00020000)
#define INTC_SECR0      (PRU_INTC + 0x280)

// ADC
#define ADC_TSC         0x44E0D000
#define SYSCONFIG       (ADC_TSC + 0x10)
#define IRQSTATUS_RAW   (ADC_TSC + 0x24)
#define IRQSTATUS       (ADC_TSC + 0x28)
#define IRQENABLE_CLR   (ADC_TSC + 0x30)
#define IRQWAKEUP       (ADC_TSC + 0x34)
#define DMAENABLE_CLR   (ADC_TSC + 0x3C)
#define ADC_CTRL        (ADC_TSC + 0x40)
#define ADCSTAT         (ADC_TSC + 0x44)
#define ADC_CLKDIV      (ADC_TSC + 0x4C)
#define STEPENABLE      (ADC_TSC + 0x54)
#define IDLECONFIG      (ADC_TSC + 0x58)
#define STEPCONFIG1     (ADC_TSC + 0x64)
#define STEPDELAY1      (ADC_TSC + 0x68)
#define STEPCONFIG9     (ADC_TSC + 0xA4)
#define STEPDELAY9      (ADC_TSC + 0xA8)
#define FIFO0DATA       (ADC_TSC + 0x100)
#define FIFO1DATA       (ADC_TSC + 0x200)

// Endereçamento dos frames
#define STEP1_BUFFER    PRU0_BUFFER
#define STEP2_BUFFER    STEP1_BUFFER+(BUFFER_SIZE+1)*4
