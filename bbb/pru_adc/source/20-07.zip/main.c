// Máxima frequência de sample rate: 341,6 kHz
// Código dividido em vários arquivos fonte
// Adress table funfando
// Lendo e escrevendo em assembly na RAM da PRU1, usando as instruções LBBO e SBBO, respectivamente
// Próximo: ler e escrever em endereços fora da PRU1, usando LBCO e SBCO (aprender como que funciona as constant tables)

#include <stdint.h>
#include <stdlib.h>
#include <pru_cfg.h>
#include "rsc_table_pru1.h"
#include "adress_table.h"

#define PRU_READ        0xAA                    // Palavra de controle que habilita a leitura do PRU_BUFFER, por parte da PRU
#define ARM_READ        0xCC                    // Palavra de controle que habilita a leitura do ARM_BUFFER, por parte do ARM
#define LOCK            0xDD                    // Palavra de controle de travamento

#define CH1             1                       // Número de amostras a serem feitas do canal 1
#define CH3             2                       // Número de amostras a serem feitas do canal 3
#define PACK            4                       // Número de pacotes

// Escopo de funções

// Hardware
extern int button_state(void);
extern void debounce(void);
extern int led_read(void);
extern void led_write(int i);
extern void led_toggle(void);
/********************************************/

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
extern void bit_clear(int ADDR, int x);
extern void bit_set(int ADDR, int x);
extern void bit_write_interval(int ADDR, int MSB, int LSB, int content);
extern int bit_read(int ADDR, int x);
extern int bit_read_interval(int ADDR, int MSB, int LSB);
/********************************************/

// ADC
extern void config_ADC(void);
int* capture(int* chan, int n);
/********************************************/

// IEP
extern void set_wave_IEP(int freq, int duty);
extern void config_IEP(void);
extern void config_INTC(void);
extern int flag_IEP(void);
extern int flag_HOST(void);
extern void clear_flag_IEP(void);
/********************************************/

// Config
extern void config(void);
/********************************************/

extern void write(void);
extern void read(void);

void main(void)
{
led_write(0);
//memory(ARM_BUFFER,'w',0xBB,'k');
//config();                                               // Configura periféricos
//int* chan1 = (int*)(ARM_BUFFER);                        // Aloca vetor para receber as amostras do canal 1
//while(1)
//    {
//    if(flag_HOST())                                     // Aguarda uma interrupção do HOST
//        {
//        if(flag_IEP())                                  // Checa se a fonte de interrupção é de fato o timer IEP
//            {
//            led_toggle();
////            asm("ADD r1,r1,0x25");
//            chan1[0] = (memory(FIFO1DATA,'r',0x00,'o'))&(0xFFF); // Captura o resultado da conversão
//            clear_flag_IEP();                           // Limpa os flags associados ao evento IEP_EVENT do TIMER IEP
//            }
//        }
//    bit_set(STEPENABLE,1);                              // Habilita canal
////    memory(ARM_BUFFER,'w',chan1[0],'k');              // Transmissão das amostras
//    }
while(1)
    {
    if(button_state())
        {
        debounce();
        led_toggle();
        if(led_read()) read();
        else write();
        }
    }
}
