#include <stdint.h>
#include <pru_cfg.h>
#include <pru_ctrl.h>
#include "adress_table.h"
#include "frame_table.h"

// Config
extern void config_IEP(void);
extern void config_INTC(void);
extern void config_ADC(void);
/********************************************/

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
/********************************************/

// Assembly
extern void init(void);
/********************************************/


// Função:    config
// Descrição: Configura periféricos
// Entrada:   -
// Saída:     -
/*********************************************************************************/
void config(void)
{
CT_CFG.SYSCFG_bit.STANDBY_INIT = 0;                                 // Endereçamento global
PRU1_CTRL.CTPPR0_bit.C28_BLK_POINTER = 0x0100;                      // Faz c28 apontar para o CONTROL_BUFFER
memory(CONTROL_BUFFER,'w',FIFO0DATA,'k');                           // Escreve o endereço de FIFO0DATA no CONTROL_BUFFER
memory(CONTROL_BUFFER+4,'w',FIFO1DATA,'k');                         // Escreve o endereço de FIFO1DATA no CONTROL_BUFFER
memory(CONTROL_BUFFER+8,'w',STEPENABLE,'k');                        // Escreve o endereço de STEPENABLE no CONTROL_BUFFER
memory(CONTROL_BUFFER+12,'w',STEP1_BUFFER,'k');                     // Escreve o endereço inicial do frame STEP1 no CONTROL_BUFFER
memory(CONTROL_BUFFER+16,'w',(STEP1_BUFFER+BUFFER_SIZE*4),'k');     // Escreve o endereço final do frame STEP1 no CONTROL_BUFFER
memory(CONTROL_BUFFER+20,'w',STEP2_BUFFER,'k');                     // Escreve o endereço inicial do frame STEP2 no CONTROL_BUFFER
memory(CONTROL_BUFFER+24,'w',(STEP2_BUFFER+BUFFER_SIZE*4),'k');     // Escreve o endereço final do frame STEP2 no CONTROL_BUFFER
memory(CONTROL_BUFFER+28,'w',0x202,'k');                            // Escreve a palavra de habilitação do STEP1 e STEP2 no CONTROL_BUFFER
memory(CONTROL_BUFFER+32,'w',EOF,'k');                              // Escreve a palavra de EOF no CONTROL_BUFFER
memory(CONTROL_BUFFER+36,'w',CONTROL_BUFFER,'k');                   // Escreve o endereço de CONTROL_BUFFER no CONTROL_BUFFER
init();                                                             // Lê o CONTROL_BUFFER e armazena em r7, r8, r9, r10, r11, r12, r13, r21, r22 e r23
config_ADC();                                                       // Configura o módulo ADC
config_IEP();                                                       // Configura TIMER IEP
config_INTC();                                                      // Configura INTC da PRU
}
/********************************************/
