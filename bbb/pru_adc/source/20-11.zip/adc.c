#include <stdlib.h>
#include "adress_table.h"

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
extern void bit_clear(int ADDR, int x);
extern void bit_set(int ADDR, int x);
extern void bit_write_interval(int ADDR, int MSB, int LSB, int content);
extern int bit_read(int ADDR, int x);
extern int bit_read_interval(int ADDR, int MSB, int LSB);
/********************************************/

// Função:    config_ADC
// Descrição: Configura o módulo ADC
// Entrada:   -
// Saída:     -
/*********************************************************************************/
void config_ADC(void)
{
// ADC_CTRL
bit_clear(ADC_CTRL,0);                        // Desabilita o módulo ADC
bit_clear(ADC_CTRL,9);                        // Eventos ativados por software são prioritários aos eventos ativados por hardware
bit_clear(ADC_CTRL,8);                        // Mapeia evento de hardware para pen_event
bit_clear(ADC_CTRL,7);                        // Desabilita touchscreen
bit_write_interval(ADC_CTRL,6,5,0x0);         // Desabilita os modos 4-wire e 5-wire
bit_clear(ADC_CTRL,3);                        // Seleciona bias interno para AFE (analog front-end: parte do ADC que efetivamente converte)
bit_set(ADC_CTRL,2);                          // Habilita a escrita nos registradores STEPCONFIGx
bit_clear(ADC_CTRL,1);                        // Desabilita a escrita da ID do canal sampleado nos registradores FIFOx

// ADC_CLKDIV
bit_write_interval(ADC_CLKDIV,15,0,0x00);     // Define clock do ADC como sendo 24 MHz

// STEPCONFIG1
bit_clear(STEPCONFIG1,27);                    // Desabilita out-of-range check (compara o valor em FIFOx com os limites definidos em ADCRANGE)
bit_clear(STEPCONFIG1,26);                    // Define FIFO0 como local do resultado da conversão
bit_clear(STEPCONFIG1,25);                    // Define como single-ended
bit_write_interval(STEPCONFIG1,24,23,0b00);   // Define referência negativa como sendo VSSA
bit_write_interval(STEPCONFIG1,22,19,0b0000); // Associona o STEP1 com  o canal 1  (AIN0)
bit_write_interval(STEPCONFIG1,14,12,0b000);  // Define referência positiva como sendo VDDA_ADC
bit_write_interval(STEPCONFIG1,4,2,0b001);    // Define número de médias igual a 2
bit_write_interval(STEPCONFIG1,1,0,0b00);     // Conversão single-shot habilitada por software

// STEPDELAY1
bit_write_interval(STEPDELAY1,17,0,0x0);      // Mínimo open delay
bit_write_interval(STEPDELAY1,31,24,0x0);     // Mínimo sample delay

// STEPCONFIG9
bit_clear(STEPCONFIG9,27);                    // Desabilita out-of-range check (compara o valor em FIFOx com os limites definidos em ADCRANGE)
bit_set(STEPCONFIG9,26);                      // Define FIFO1 como local do resultado da conversão
bit_clear(STEPCONFIG9,25);                    // Define como single-ended
bit_write_interval(STEPCONFIG9,24,23,0b00);   // Define referência negativa como sendo VSSA
bit_write_interval(STEPCONFIG9,22,19,0b0110); // Associona o STEP9 com  o canal 7  (AIN6)
bit_write_interval(STEPCONFIG9,14,12,0b000);  // Define referência positiva como sendo VDDA_ADC
bit_write_interval(STEPCONFIG9,4,2,0b001);    // Define número de médias igual a 2
bit_write_interval(STEPCONFIG9,1,0,0b00);     // Conversão single-shot habilitada por software

// STEPDELAY9
bit_write_interval(STEPDELAY9,17,0,0x0);      // Mínimo open delay
bit_write_interval(STEPDELAY9,31,24,0x0);     // Mínimo sample delay

// DMAENABLE_CLR
bit_clear(DMAENABLE_CLR,1);                   // Desabilita recurso de DMA do registro FIFO1
bit_clear(DMAENABLE_CLR,1);                   // Desabilita recurso de DMA do registro FIFO0

// IRQWAKEUP
bit_clear(IRQWAKEUP,0);                       // Desabilita wakeup generation of hw pen event

// IRQSTATUS_RAW
bit_write_interval(IRQSTATUS,10,0,0x7FF);     // Limpa os flags pendentes de todas as interrupções do módulo ADC (mesmo aquelas mascaradas)

// IRQSTATUS
bit_write_interval(IRQSTATUS,10,0,0x7FF);     // Limpa os flags pendentes de todas as interrupções do módulo ADC

// IRQENABLE_CLR
bit_write_interval(IRQENABLE_CLR,10,0,0x7FF); // Desabilita todas as interrupções do módulo ADC

// STEPENABLE
bit_write_interval(STEPENABLE,16,0,0x0);      // Desabilita todos os STEPS

// ADC_CTRL
bit_clear(ADC_CTRL,4);                        // Garante que o AFE está energizado
bit_set(STEPENABLE,1);                        // Habilita STEP1
bit_set(STEPENABLE,9);                        // Habilita STEP9
bit_set(ADC_CTRL,0);                          // Habilita o módulo ADC
}
/********************************************/
