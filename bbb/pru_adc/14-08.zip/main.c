// Máxima frequência de sample rate: 300 kHz
// Divisão por 4 devido às 2 médias e 2 canais
// Sinalização de fim de frame, garantindo sincronismo na captura do frame, contagem de frequência e transmissão do frame para o ARM_BUFFER

#include <stdint.h>
#include <stdlib.h>
#include <pru_cfg.h>
#include "rsc_table_pru1.h"

// Escopo de funções

// Hardware
extern int button_state(void);
extern void debounce(void);
extern int led_read(void);
extern void led_write(int i);
extern void led_toggle(void);
/********************************************/

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
extern void bit_clear(int ADDR, int x);
extern void bit_set(int ADDR, int x);
extern void bit_write_interval(int ADDR, int MSB, int LSB, int content);
extern int bit_read(int ADDR, int x);
extern int bit_read_interval(int ADDR, int MSB, int LSB);
/********************************************/

// ADC
extern void config_ADC(void);
int* capture(int* chan, int n);
/********************************************/

// IEP
extern void set_wave_IEP(int freq, int duty);
extern void config_IEP(void);
extern void config_INTC(void);
extern int flag_IEP(void);
extern int flag_HOST(void);
extern void clear_flag_IEP(void);
/********************************************/

// Config
extern void config(void);
/********************************************/

// Assembly
extern void init(void);
extern void sample(void);
extern void restart(void);
/********************************************/

void main(void)
{
config();                                               // Configura periféricos
while(1)
    {
    if(flag_HOST()&&flag_IEP())                         // Aguarda uma interrupção do HOST e checa se a fonte de interrupção é de fato o timer IEP
        {
        led_toggle();                                   // Debug de velocidade do algoritmo
        sample();                                       // Captura dos canais AIN0 e AIN7
        clear_flag_IEP();                               // Limpa os flags associados ao evento IEP_EVENT do TIMER IEP
        }
    restart();                                          // Restaura ponteiros de resultado às posições iniciais dos frames
    }
}
