#include <stdint.h>
#include <pru_cfg.h>
#include <pru_ctrl.h>
#include "adress_table.h"
#include "frame_table.h"

// Config
extern void config_IEP(void);
extern void config_INTC(void);
extern void config_ADC(void);
/********************************************/

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
/********************************************/

// Assembly
extern void init(void);
/********************************************/


// Função:    config
// Descrição: Configura periféricos
// Entrada:   -
// Saída:     -
/*********************************************************************************/
void config(void)
{
CT_CFG.SYSCFG_bit.STANDBY_INIT = 0;                 // Endereçamento global
PRU1_CTRL.CTPPR0_bit.C28_BLK_POINTER = 0x0100;      // Faz c28 apontar para o CONTROL_BUFFER
memory(CONTROL_BUFFER,'w',FIFO1DATA,'k');           // Escreve o endereço de FIFO1DATA no CONTROL_BUFFER
memory(CONTROL_BUFFER+4,'w',STEPENABLE,'k');        // Escreve o endereço de STEPENABLE no CONTROL_BUFFER
memory(CONTROL_BUFFER+8,'w',PRU0_BUFFER,'k');       // Escreve o endereço de PRU0_BUFFER no CONTROL_BUFFER
memory(CONTROL_BUFFER+12,'w',PRU0_BUFFER+FRAME_SIZE*4,'k');       // Escreve o endereço final do frame no CONTROL_BUFFER
init();                                             // Lê o CONTROL_BUFFER e armazena em r10, r11, r12, r13 e r14
config_ADC();                                       // Configura o módulo ADC
config_IEP();                                       // Configura TIMER IEP
config_INTC();                                      // Configura INTC da PRU
}
/********************************************/
