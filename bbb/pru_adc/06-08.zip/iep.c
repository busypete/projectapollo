#include <stdint.h>
#include <pru_cfg.h>
#include <pru_iep.h>
#include <pru_intc.h>
#include "adress_table.h"

volatile register uint32_t __R31;               // Registro de entrada

#define IEP_CLK         200000000               // Fonte de clock do TIMER IEP (200 MHz)
#define FREQ            453000                  // Frequência da onda gerada pelo TIMER IEP
#define DUTY            50                      // Duty cycle da onda gerada pelo TIMER IEP

#define IEP_EVENT       (1<<7)                  // Número do system event correspondente ao IEP
#define HOST_EVENT      (1<<30)                 // Bit do registrador R31 correspondente à Host Interrupt 0
#define PRU_CHANNEL     1                       // Canal de interrupção intermediário do INTC da PRU
#define HOST_CHANNEL    0                       // Canal de interrupção final do INTC da PRU

// Hardware
extern int led_read(void);
extern void led_toggle(void);
/********************************************/

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
extern void bit_write_interval(int ADDR, int MSB, int LSB, int content);
extern void bit_set(int ADDR, int x);
/********************************************/

// Função:    set_wave_IEP
// Descrição: Seta a frequência e o ciclo de trabalho da onda gerada pelo TIMER IEP
// Entrada:   int freq              - valor da frequência em Hz
//            int duty              - ciclo de trabalho de 0% a 100%
// Saída:     -
/*********************************************************************************/
void set_wave_IEP(int freq, int duty)
{
static int period = 0, low = 0, high = 0, i = 0;
if(i==0)
    {
    period = IEP_CLK/freq;
    high = (duty*period)/100;
    low = period-high;
    i++;
    }
led_toggle();
if(led_read()) CT_IEP.TMR_CMP0 = high;
else CT_IEP.TMR_CMP0 = low;
}
/********************************************/

// Função:    config_IEP
// Descrição: Configura TIMER IEP
// Entrada:   -
// Saída:     -
/*********************************************************************************/
void config_IEP(void)
{
CT_IEP.TMR_GLB_CFG_bit.CNT_EN = 0;              // Desabilita TIMER
CT_IEP.TMR_CNT = 0x0;                           // Limpa o registro de contagem do TIMER
CT_IEP.TMR_GLB_STS_bit.CNT_OVF = 1;             // Limpa o flag de overflow
CT_IEP.TMR_CMP_STS_bit.CMP_HIT = 0xFF;          // Limpa os flags de comparação

set_wave_IEP(FREQ,DUTY);                        // Gera uma onda de FREQ Hz e duty cycle de DUTY %
CT_IEP.TMR_CMP_CFG_bit.CMP_EN = 0x01;           // Habilita o evento de comparação 0
CT_IEP.TMR_CMP_CFG_bit.CMP0_RST_CNT_EN = 1;     // Habilita o reset da contagem na ocorrência do evento de comparação 0
CT_IEP.TMR_GLB_CFG_bit.DEFAULT_INC = 0x1;       // Define incremento de 1 nas contagens do timer
CT_IEP.TMR_COMPEN_bit.COMPEN_CNT = 0x0;         // Desabilita compensação de contagem
CT_IEP.TMR_GLB_CFG_bit.CNT_EN = 1;              // Habilita TIMER
}
/********************************************/

// Função:    config_INTC
// Descrição: Configura INTC da PRU
// Entrada:   -
// Saída:     -
/*********************************************************************************/
void config_INTC(void)
{
CT_INTC.SIPR0_bit.POLARITY_31_0 |= IEP_EVENT;   // Define a polaridade da interrupção (borda de subida)
CT_INTC.SITR0_bit.TYPE_31_0 &= ~(IEP_EVENT);    // Define o tipo da interrupção (tipo pulso)
CT_INTC.CMR1_bit.CH_MAP_7 = PRU_CHANNEL;        // Mapeia o evento IEP_EVENT (system event) para o canal de interrupção intermediário PRU_CHANNEL do INTC da PRU
CT_INTC.HMR0_bit.HINT_MAP_1 = HOST_CHANNEL;     // Mapeia o canal de interrupção intermediário PRU_CHANNEL do INTC da PRU para o canal de interrupção final HOST_CHANNEL da PRU                                                // Canais 0 e 1 são da PRU e canais 8 a 10 vão para o INTC do ARM HOST para integrar outros módulos do SoC

CT_INTC.SECR0 = 0xFFFFFFFF;                     // Limpa os flags de pendência das interrupções de todos os eventos do sistema
CT_INTC.SECR1 = 0xFFFFFFFF;
CT_INTC.EISR_bit.EN_SET_IDX |= IEP_EVENT;       // Habilita as interrupções geradas pelo evento IEP_EVENT (interrupções de compare e capture do periférico IEP)
CT_INTC.HIER_bit.EN_HINT |= (1<<HOST_CHANNEL);  // Habilita as interrupções geradas pelo canal de interrrupção HOST_CHANNEL do INTC da PRU
CT_INTC.GER_bit.EN_HINT_ANY = 1;                // Enable geral das interrupções
}
/********************************************/

// Função:    flag_IEP
// Descrição: Retorna o estado do flag de pendência do evento IEP_EVENT do TIMER IEP
// Entrada:   -
// Saída:     int                   - 0: flag de pendência inativo
//                                  - 1: flag de pendência ativo
/*********************************************************************************/
int flag_IEP(void)
{
return(CT_INTC.SECR0 & (IEP_EVENT));            // Testa se o flag de pendência do evento IEP_EVENT está ativo
}
/********************************************/

// Função:    flag_HOST
// Descrição: Retorna o estado do flag de pendência do evento HOST_EVENT do INTC da PRU
// Saída:     int                   - 0: flag de pendência inativo
//                                  - 1: flag de pendência ativo
/*********************************************************************************/
int flag_HOST(void)
{
return(__R31 & (HOST_EVENT));                   // Testa se o flag de pendência do canal HOST_EVENT está ativo
}
/********************************************/

// Função:    clear_flag_IEP
// Descrição: Limpa os flags associados ao evento IEP_EVENT do TIMER IEP
// Entrada:   -
// Saída:     -
void clear_flag_IEP()
{
CT_IEP.TMR_CMP_STS_bit.CMP_HIT = 0xFF;  // Limpa os flags de comparação
CT_IEP.TMR_GLB_STS_bit.CNT_OVF = 1;     // Limpa o flag de overflow
CT_INTC.SECR0 |= IEP_EVENT;             // Limpa o flag de pendência do evento IEP_EVENT
}
/********************************************/
