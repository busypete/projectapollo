// Controle do frame
#define EOF                 0xAA                                    // Fim de frame
#define LOCK                0xBB                                    // Travamento de frame

// Parâmetros do scope
#define SAMPLE_RATE         189000                                  // Frequência de amostragem atual do sinal de entrada
#define TRIGGER_LEVEL       300                                     // Nível da conversão AD onde o trigger ocorre

// Dimensões do frame
#define SAMPLE_PER_PERIOD   12                                      // Número de amostras por período
#define PERIOD_PER_FRAME    10                                      // Número de períodos por frame (será uma função de TIME/DIV)
#define FRAME_SIZE          SAMPLE_PER_PERIOD*PERIOD_PER_FRAME      // Número de amostras por frame


