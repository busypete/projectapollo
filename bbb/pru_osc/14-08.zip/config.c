#include <stdint.h>
#include <pru_cfg.h>

// Função:    config
// Descrição: Configura periféricos
// Entrada:   -
// Saída:     -
/*********************************************************************************/
void config(void)
{
CT_CFG.SYSCFG_bit.STANDBY_INIT = 0;             // Endereçamento global
}
/********************************************/
