// PRU BUFFER
#define PRU_ICSS            0x4A300000
#define PRU0_BUFFER         PRU_ICSS+0x00000000                 // Frame genérico da RAM PRU0
#define PRU1_BUFFER         PRU_ICSS+0x00002000                 // Frame genérico da RAM PRU1
#define CONTROL_BUFFER      PRU_ICSS+0x00010000                 // Frame de controle (RAM compartilhada entre as PRU's)

