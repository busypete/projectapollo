#include <stdlib.h>
#include "frame_table.h"

extern int rx[FRAME_SIZE];

// Função:    frame_read
// Descrição: Leitura de um vetor de inteiros na memória
// Entrada:   unsigned int ADDR     - endereço a partir do qual o vetor será lido
//            unsigned int length   - tamanho do vetor
// Saída:     -
/*********************************************************************************/
frame_read(unsigned int ADDR, unsigned int length)
{
int* pointer = (int*)(ADDR);                             // Ponteiro para o frame
int i = 0;
for(i=0;i<length;i++)
    {
    rx[i] = *pointer;                                    // Dereferencia ponteiro
    pointer++;                                           // Atualiza ponteiro
    }
}
/********************************************/

/*********************************************************************************/
// Função:    frame_write
// Descrição: Escreve um vetor de inteiros na memória.
// Entrada:   int*       vector   - vetor a ser impresso
//            unsigned int length   - tamanho do vetor a ser impresso
//            unsigned int ADDR     - endereço a partir do qual o vetor será impresso
// Saída:     -
/*********************************************************************************/
void frame_write(int* vector, unsigned int ADDR, unsigned int length)
{
int i;                                                          // Índice de iteração
int* pointer = (int*)(ADDR);                                    // Ponteiro para o frame da PRU
for(i=0;i<length;i++)
    {
    *pointer = vector[i];                                       // Escreve cada posição do vetor no frame
    pointer++;                                                  // Atualiza ponteiro
    }
}
/********************************************/

// Função:    compare_vector
// Descrição: Compara dois vetores. Necessariamente, eles devem possuir a mesma dimensão
// Entrada:   int* vector1          - operando 1
//            int* vector1          - operando 2
//            unsigned int length   - tamanho dos vetores
// Saída:     0                     - vetores diferentes
//            1                     - vetores iguais
/*********************************************************************************/
int compare_vector(int* vector1, int* vector2, unsigned int length)
{
int i,match = 0;                                // Índice de iteração e número de matches
for(i=0;i<length;i++)                           // Aplica a restrição de igual a cada posição dos vetores
    {
    if(vector1[i]==vector2[i]) match++;         // Incrementa o acumulador de matches
    else break;                                 // Quebra o laço quando encontrar qualquer diferença
    }
if(match==length) return(1);                    // Vetores idênticos
else return(0);
}
/********************************************/

// Função:    frame_maker
// Descrição: Produz um frame a partir da captura serial de um buffer de interesse.
// Entrada:   unsigned int ADDR     - posição de memória de interesse
//            unsigned int length   - tamanho do frame
// Saída:     int*                  - vetor contendo o frame
/*********************************************************************************/
int* frame_maker(unsigned int ADDR, unsigned int length)
{
int* pointer = (int*)(ADDR);                        // Ponteiro fixo para o buffer de interesse
int* data = (int*)(malloc(length*sizeof(int)));     // Aloca o vetor com o resultado do frame
int i = 0;                                          // Índice de iteração
for(i=0;i<length;i++) data[i] = *pointer;
return(data);
}
/********************************************/

// Função:    freq_counter
// Descrição: Calcula a frequência, em Hz, com que os valores de um vetor cruzam
//            um determinado valor de referência.
// Entrada:   int* vector                   - vetor de dados
//            unsigned int sample_rate      - frequência de amostragem
//            int trigger_level             - valor de referência
//            unsigned int length           - tamanho dos vetores
// Saída:     int                           - frequência
/*********************************************************************************/
int freq_counter(int* vector, unsigned int sample_rate, int trigger_level, unsigned int length)
{
int i = 0, current_wave_cycle = 0, old_wave_cycle = 0, trigger_count = 0, first_trigger = 0, second_trigger = 0, freq = 0;
for(i=0;i<length;i++)
    {
    if(vector[i]<trigger_level) current_wave_cycle = 0;
    else current_wave_cycle = 1;
    if((current_wave_cycle!=old_wave_cycle)&&(i>=1))
        {
        trigger_count++;
        if(trigger_count==1) first_trigger = i;
        else if(trigger_count==2) second_trigger = i;
        }
    if(trigger_count>=2)
       {
       freq = (sample_rate)/(2*(second_trigger-first_trigger));
       break;
       }
    old_wave_cycle = current_wave_cycle;
    }
return(freq);
}
/********************************************/
