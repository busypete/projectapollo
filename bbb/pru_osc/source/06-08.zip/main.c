// Máxima frequência de frame rate: 13,8 kHz (frame de 120 pontos: 10 pontos por período, 12 períodos por janela; algoritmo bastante linear)
// Contador de frequência funcionando (é interessante que o ARM não consegue acompanhar a velocidade do frame, mas a medida está cravada)
// Limitação: não consegue medir ondas que não são periódicas dentro de uma janela (mais lentas que a janela)
// Ponto positivo: consegue medir ondas tão rápidas a ponto de cruzar o trigger-level entre amostras sucessivas
// Próximo: entender e implementar função de trigger

#include <stdint.h>
#include <stdlib.h>
#include <pru_cfg.h>
#include "resource_table_empty.h"
#include "adress_table.h"
#include "frame_table.h"

// Escopo de funções

// Hardware
extern int button_state(void);
extern void debounce(void);
extern int led_read(void);
extern void led_write(int i);
extern void led_toggle(void);
/********************************************/

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
extern void bit_clear(int ADDR, int x);
extern void bit_set(int ADDR, int x);
extern void bit_write_interval(int ADDR, int MSB, int LSB, int content);
extern int bit_read(int ADDR, int x);
extern int bit_read_interval(int ADDR, int MSB, int LSB);
/********************************************/

// Frame
extern frame_read(unsigned int ADDR, unsigned int length);
extern void frame_write(int* vector, unsigned int ADDR, unsigned int length);
extern int compare_vector(int* vector1, int* vector2, unsigned int length);
extern int* frame_maker(unsigned int ADDR, unsigned int length);
extern int freq_counter(int* vector, unsigned int sample_rate, int trigger_level, unsigned int length);
/********************************************/

// Config
extern void config(void);
/********************************************/

int rx[FRAME_SIZE];                                     // Variável global para capturar o frame da conversão AD (alocação dinâmica deu ruim)

void main(void)
{
int* pointer = (int*)(CONTROL_BUFFER);
while(1)
    {
    frame_read(PRU0_BUFFER,FRAME_SIZE);                                         // Captura o frame da conversão AD
    frame_write(rx,PRU1_BUFFER,FRAME_SIZE);                                     // Envia o frame tratado para o ARM
    *pointer = freq_counter(rx,453000*2,TRIGGER_LEVEL,FRAME_SIZE);              // Determina a frequência do frame recém-capturado
    led_toggle();                                                               // Debug de frequência do algoritmo
    }
}
