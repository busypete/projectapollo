// Controle do frame
#define ARM_READ            0xCC
#define LOCK                0xDD

// Parâmetros do scope
#define MAX_SAMPLE_RATE     1200000                                 // Máxima frequência de amostragem do sinal de entrada
#define MAX_FREQ            20000                                   // Máxima frequência do sinal de entrada
#define TRIGGER_LEVEL       300

// Dimensões do frame
#define SAMPLE_PER_PERIOD   12                                      // Número de amostras por período
#define PERIOD_PER_FRAME    10                                      // Número de períodos por frame (será uma função de TIME/DIV)
#define FRAME_SIZE          SAMPLE_PER_PERIOD*PERIOD_PER_FRAME      // Número de amostras por frame

