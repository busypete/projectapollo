#include <stdlib.h>

// Função:    frame_read
// Descrição: Leitura de um vetor de inteiros na memória
// Entrada:   unsigned int ADDR     - endereço a partir do qual o vetor será lido
// Saída:     int*                  - vetor contendo a leitura do frame
/*********************************************************************************/
int* frame_read(unsigned int ADDR)
{
int i, length;                                           // Índice de iteração e tamanho do frame
int* pointer = (int*)(ADDR);                             // Ponteiro para o frame
length = *pointer;                                       // Captura o tamanho do frame
int* readback = (int*)(malloc(length*sizeof(int)));      // Aloca o vetor com o resultado da leitura
for(i=1;i<(length+1);i++)
    {
    pointer = (int*)(ADDR+sizeof(int)*i);                // Atualiza ponteiro
    readback[i-1] = *pointer;                            // Dereferencia ponteiro
    }
return(readback);
}
/********************************************/

/*********************************************************************************/
// Função:    frame_write
// Descrição: Escreve um vetor de inteiros na memória. A primeira posição do frame
//            recebe o tamanho do frame
// Entrada:   int*       vector   - vetor a ser impresso
//            unsigned int length   - tamanho do vetor a ser impresso
//            unsigned int ADDR     - endereço a partir do qual o vetor será impresso
// Saída:     -
/*********************************************************************************/
void frame_write(int* vector, unsigned int length, unsigned int ADDR)
{
int i;                                                          // Índice de iteração
int* pointer = (int*)(ADDR);                                    // Ponteiro para o frame da PRU
*pointer = length;                                              // Envia o tamanho do vetor na primeira posição do frame
for(i=1;i<(length+1);i++)
    {
    pointer = (int*)(ADDR+sizeof(int)*i);                       // Atualiza ponteiro
    *pointer = vector[i-1];                                     // Escreve cada posição do vetor no frame buffer da PRU
    }
}
/********************************************/

// Função:    compare_vector
// Descrição: Compara dois vetores. Necessariamente, eles devem possuir a mesma dimensão
// Entrada:   int* vector1          - operando 1
//            int* vector1          - operando 2
//            unsigned int length   - tamanho dos vetores
// Saída:     0                     - vetores diferentes
//            1                     - vetores iguais
/*********************************************************************************/
int compare_vector(int* vector1, int* vector2, unsigned int length)
{
int i,match = 0;                                // Índice de iteração e número de matches
for(i=0;i<length;i++)                           // Aplica a restrição de igual a cada posição dos vetores
    {
    if(vector1[i]==vector2[i]) match++;         // Incrementa o acumulador de matches
    else break;                                 // Quebra o laço quando encontrar qualquer diferença
    }
if(match==length) return(1);                    // Vetores idênticos
else return(0);
}
/********************************************/

// Função:    frame_maker
// Descrição: Produz um frame a partir da captura serial de um buffer de interesse.
// Entrada:   unsigned int ADDR     - posição de memória de interesse
//            unsigned int length   - tamanho do frame
// Saída:     int*                  - vetor contendo o frame
/*********************************************************************************/
int* frame_maker(unsigned int ADDR, unsigned int length)
{
int* pointer = (int*)(ADDR);                        // Ponteiro fixo para o buffer de interesse
int* data = (int*)(malloc(length*sizeof(int)));     // Aloca o vetor com o resultado do frame
int i = 0;                                          // Índice de iteração
for(i=0;i<length;i++) data[i] = *pointer;
return(data);
}
/********************************************/
