﻿// Máxima frequência de frame rate: 29 kHz (frame de 60 pontos: 10 pontos por período, 6 períodos por janela)
// Próximo: função de contador de  frequência


// Próximo: construir o frame no pru_adc (incrementa r12 a cada envio pro PRU0_BUFFER e restaura pra posição inicial depois de FRAME_SIZE envios) #include <stdint.h>
#include <stdlib.h>
#include <pru_cfg.h>
#include "resource_table_empty.h"
#include "adress_table.h"

// Controle do frame
#define ARM_READ            0xCC
#define LOCK                0xDD

// Dimensões do frame
#define MAX_SAMPLE_RATE     1200000                                 // Máxima frequência de amostragem do sinal de entrada
#define MAX_FREQ            20000                                   // Máxima frequência do sinal de entrada
#define SAMPLE_PER_PERIOD   10                                      // Número de amostras por período
#define PERIOD_PER_FRAME    6                                       // Número de períodos por frame (será uma função de TIME/DIV)
#define FRAME_SIZE          SAMPLE_PER_PERIOD*PERIOD_PER_FRAME      // Número de amostras por frame

// Escopo de funções

// Hardware
extern int button_state(void);
extern void debounce(void);
extern int led_read(void);
extern void led_write(int i);
extern void led_toggle(void);
/********************************************/

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
extern void bit_clear(int ADDR, int x);
extern void bit_set(int ADDR, int x);
extern void bit_write_interval(int ADDR, int MSB, int LSB, int content);
extern int bit_read(int ADDR, int x);
extern int bit_read_interval(int ADDR, int MSB, int LSB);
/********************************************/

// Frame
extern int* frame_read(unsigned int ADDR);
extern void frame_write(int* vector, unsigned int length, unsigned int ADDR);
extern int compare_vector(int* vector1, int* vector2, unsigned int length);
extern int* frame_maker(unsigned int ADDR, unsigned int length);
/********************************************/

// Config
extern void config(void);
/********************************************/

void main(void)
{
config();                                               // Configura periféricos
int* data = (int*)(malloc(FRAME_SIZE*sizeof(int)));     // Aloca o vetor com o resultado do frame
while(1)
    {
    data = frame_maker(PRU0_BUFFER,FRAME_SIZE);
    frame_write(data,FRAME_SIZE,PRU1_BUFFER);
    led_toggle();
    }
}
