
/*********************************************************************************/
// Função:    frame_move
// Descrição: Move um frame de inteiros na memória.
// Entrada:   unsigned int ADDR1    - endereço inicial do frame de origem
//            unsigned int ADDR2    - endereço inicial do frame de destino
//            unsigned int length   - tamanho do frame
// Saída:     -
/*********************************************************************************/
void frame_move(unsigned int ADDR1, unsigned int ADDR2, unsigned int length)
{
int i;                                                   // Índice de iteração
int* origin = (int*)(ADDR1);                             // Ponteiro para o frame de origem
int* destiny = (int*)(ADDR2);                            // Ponteiro para o frame de destino
for(i=0;i<length;i++)
    {
    *destiny = *origin;                                  // Transfere cada posição do frame
    origin++;                                            // Atualiza ponteiro do frame de origem
    destiny++;                                           // Atualiza ponteiro do frame de destino
    }
}
/********************************************/

/*********************************************************************************/
// Função:    frame_write
// Descrição: Escreve um vetor de inteiros na memória.
// Entrada:   int*       vector     - vetor a ser impresso
//            unsigned int length   - tamanho do vetor a ser impresso
//            unsigned int ADDR     - endereço a partir do qual o vetor será impresso
// Saída:     -
/*********************************************************************************/
void frame_write(int* vector, unsigned int ADDR, unsigned int length)
{
int i;                                                          // Índice de iteração
int* pointer = (int*)(ADDR);                                    // Ponteiro para o frame da PRU
for(i=0;i<length;i++)
    {
    *pointer = vector[i];                                       // Escreve cada posição do vetor no frame
    pointer++;                                                  // Atualiza ponteiro
    }
}
/********************************************/
