// PRU BUFFER
#define PRU_ICSS            0x4A300000
#define PRU0_BUFFER         PRU_ICSS+0x00000000                 // Frame genérico da RAM PRU0
#define PRU1_BUFFER         PRU_ICSS+0x00002000                 // Frame genérico da RAM PRU1
#define CONTROL_BUFFER      PRU_ICSS+0x00010000                 // Frame de controle (RAM compartilhada entre as PRU's)

// Endereçamento dos frames
#define STEP1_BUFFER        PRU0_BUFFER
#define STEP2_BUFFER        STEP1_BUFFER+((BUFFER_SIZE/2)+1)*4
#define ARM1_BUFFERA        PRU1_BUFFER
#define ARM1_BUFFERB        ARM1_BUFFERA+((BUFFER_SIZE/2)+1)*4
#define ARM2_BUFFERA        CONTROL_BUFFER+0x1000
#define ARM2_BUFFERB        ARM2_BUFFERA+((BUFFER_SIZE/2)+1)*4
