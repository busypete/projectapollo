#include <stdint.h>
#include <stdlib.h>
#include <pru_cfg.h>
#include "resource_table_empty.h"
#include "adress_table.h"
#include "frame_table.h"

// Escopo de funções

// Hardware
extern void led_toggle(void);
/********************************************/

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
/********************************************/

// Frame
extern void frame_move(unsigned int ADDR1, unsigned int ADDR2, unsigned int length);
extern void frame_write(int* vector, unsigned int ADDR, unsigned int length);
/********************************************/

void main(void)
{
CT_CFG.SYSCFG_bit.STANDBY_INIT = 0;                                 // Endereçamento global
while(1)
    {
    // Testa se a aplicação do QT não está lendo o frame atualmente
    if((memory(CONTROL_BUFFER,'r',0x00,'o')==QTLAZY))
        {
        while(memory(CONTROL_BUFFER,'r',0x00,'o')!=EOF);            // Aguarda evento de EOF
        frame_move(STEP1_BUFFER,ARM1_BUFFERA,BUFFER_SIZE);          // Transfere STEP1_BUFFER para o ARM1_BUFFERA
        frame_move(STEP2_BUFFER,ARM2_BUFFERA,BUFFER_SIZE);          // Transfere STEP2_BUFFER para o ARM2_BUFFERA
        while(memory(CONTROL_BUFFER,'r',0x00,'o')!=EOF);            // Aguarda evento de EOF
        frame_move(STEP1_BUFFER,ARM1_BUFFERB,BUFFER_SIZE);          // Transfere STEP1_BUFFER para o ARM1_BUFFERB
        frame_move(STEP2_BUFFER,ARM2_BUFFERB,BUFFER_SIZE);          // Transfere STEP2_BUFFER para o ARM2_BUFFERB
        led_toggle();                                               // Debug de velocidade do algoritmo
        }
    }
}
