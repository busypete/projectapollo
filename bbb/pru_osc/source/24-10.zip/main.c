// Contador de frequência funcionando
// Transferência do frame para o ARM_BUFFER ocorre quando a PRU1 sinaliza o final do frame e a aplicação do QT não está lendo o frame
// Próximo: implementar o TIME_DIV

#include <stdint.h>
#include <stdlib.h>
#include <pru_cfg.h>
#include "resource_table_empty.h"
#include "adress_table.h"
#include "frame_table.h"

// Escopo de funções

// Hardware
extern void led_toggle(void);
/********************************************/

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
/********************************************/

// Frame
extern void frame_move(unsigned int ADDR1, unsigned int ADDR2, unsigned int length);
/********************************************/

void main(void)
{
CT_CFG.SYSCFG_bit.STANDBY_INIT = 0;                                 // Endereçamento global
while(1)
    {
    // Testa se a aplicação do QT não está lendo o frame atualmente
    if((memory(CONTROL_BUFFER,'r',0x00,'o')==QTLAZY))
        {
        while(memory(CONTROL_BUFFER,'r',0x00,'o')!=EOF);            // Aguarda evento de EOF
        frame_move(STEP1_BUFFER,ARM1_BUFFER,FRAME_SIZE);            // Transfere STEP1_BUFFER para o ARM1_BUFFER
        frame_move(STEP2_BUFFER,ARM2_BUFFER,FRAME_SIZE);            // Transfere STEP2_BUFFER para o ARM2_BUFFER
        led_toggle();                                               // Debug de velocidade do algoritmo
        }
    }
}
