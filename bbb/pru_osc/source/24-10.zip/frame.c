
/*********************************************************************************/
// Função:    frame_move
// Descrição: Move um frame de inteiros na memória.
// Entrada:   unsigned int ADDR1    - endereço inicial do frame de origem
//            unsigned int ADDR2    - endereço inicial do frame de destino
//            unsigned int length   - tamanho do frame
// Saída:     -
/*********************************************************************************/
void frame_move(unsigned int ADDR1, unsigned int ADDR2, unsigned int length)
{
int i;                                                   // Índice de iteração
int* origin = (int*)(ADDR1);                             // Ponteiro para o frame de origem
int* destiny = (int*)(ADDR2);                            // Ponteiro para o frame de destino
for(i=0;i<length;i++)
    {
    *destiny = *origin;                                  // Transfere cada posição do frame
    origin++;                                            // Atualiza ponteiro do frame de origem
    destiny++;                                           // Atualiza ponteiro do frame de destino
    }
}
/********************************************/
