// Controle do frame
#define EOF                 0xAA                                    // Fim de frame
#define LOCK                0xBB                                    // Travamento de frame
#define QTBUSY              0xCC                                    // Qt ocupado
#define QTLAZY              0xDD                                    // Qt livre

// Dimensões do frame
#define BUFFER_SIZE          960                                     //  Número de amostras por frame


