#include <stdint.h>

volatile register uint32_t __R30;               // Registro de saída
volatile register uint32_t __R31;               // Registro de entrada

#define LED             (1<<7)                  // P9.25 = R30_7
#define BOTAO           (1<<3)                  // P9.28 = R31_3

// Função:    button_state
// Descrição: Lê o estado do botão caracterizado pelo #define do programa
// Entrada:   -
// Saída:     unsigned int          - 0: botão não pressionado
//                                  - 1: botão pressionado
/*********************************************************************************/
int button_state(void)
{
if((__R31&BOTAO)==0) return(1);                 // Botão apertado
else return(0);                                 // Botão não apertado
}
/********************************************/

// Função:    debounce
// Descrição: Realiza debounce do botão caracterizado pelo #define do programa
// Entrada:   -
// Saída:     -
/*********************************************************************************/
void debounce(void)
{
while(button_state());
__delay_cycles(10000000);
}
/********************************************/

// Função:    led_read
// Descrição: Lê o estado lógico do LED caracterizado pelo #define do programa
// Entrada:
// Saída:     unsigned int          - 0: led apagado
//                                  - 1: led aceso
/*********************************************************************************/
int led_read(void)
{
if((__R30 &= LED)==0) return(0);                // LED apagado
else return (1);                                // LED aceso
}
/********************************************/

// Função:    led_write
// Descrição: Aplica um estado lógico ao LED caracterizado pelo #define do programa
// Entrada:   int i                 - 0: led apagado
//                                  - 1: led aceso
// Saída:     -
/*********************************************************************************/
void led_write(int i)
{
if(i==1) __R30 |= LED;                          // R30 = R30 | 0x00008000
else __R30 &= ~(LED);                           // R30 = R30 & 0xFFFF7FFF
}
/********************************************/

// Função:    led_toggle
// Descrição: Inverte o estado do LED caracterizado pelo #define do programa
// Entrada:   -
// Saída:     -
/*********************************************************************************/
void led_toggle(void)
{
__R30 ^= LED;                                   // Inverte LED
}
/********************************************/
