/*********************************************************************************/
// Função:    memory
// Descrição: Leitura e escrita em posições de memória.
//            Os argumentos 'content' e 'logic' não possuem nenhum efeito
//            caso acess = 'r'.
// Entrada:   int  ADDR             - endereço de memória de interesse
//            char acess            - 'r': leitura
//                                  - 'w': escrita
//            int  content          - conteúdo a ser escrito no endereço ADDR
//            char logic            - 'k': *ADDR = content         (overwrite)
//                                  - 'o': *ADDR |= content        (lógica OR)
//                                  - 'a': *ADDR = *ADDR & content (lógica AND)
//                                  - 'x': *ADDR = *ADDR ^ content (lógica XOR)
// Saída:     int                   - resultado da leitura
/*********************************************************************************/
int memory(int ADDR, char acess, int content, char logic)
{
int read_result = 0;                                                    // Variável para resultado da leitura
int* pointer = (int*)(ADDR);                                            // Cria ponteiro para a posição de memória de interesse

if(acess == 'r') read_result = *pointer;                                // Leitura da posição de memória
else if(acess == 'w')                                                   // Escrita na posição de memória
    {
    if(logic == 'k') *pointer = content;                                // Overwrite
    else if(logic == 'o') *pointer |= content;                          // Ĺógica OR
    else if(logic == 'a') *pointer &= content;                          // Lógica AND
    else if(logic == 'x') *pointer ^= content;                          // Lógica XOR
    read_result = *pointer;                                             // Leitura da posição de memória após a escrita
    }
return(read_result);                                                    // Retorna resultado da leitura
}
/********************************************/

/*********************************************************************************/
// Função:    bit_clear
// Descrição: Limpa um bit usando a função "memory"
// Entrada:   int ADDR              - endereço de memória de interesse
//            int x                 - bit de interesse
// Saída:     -
/*********************************************************************************/
void bit_clear(int ADDR, int x)
{
memory(ADDR,'w',(~(1<<x)),'a');
}
/********************************************/

/*********************************************************************************/
// Função:    bit_set
// Descrição: Seta um bit usando a função "memory"
// Entrada:   int  ADDR             - endereço de memória de interesse
//            int  x                - bit de interesse
// Saída:     -
/*********************************************************************************/
void bit_set(int ADDR, int x)
{
memory(ADDR,'w',(1<<x),'o');
}
/********************************************/

/*********************************************************************************/
// Função:    bit_toggle
// Descrição: Inverte um bit usando a função "memory"
// Entrada:   unsigned int  ADDR - endereço de memória de interesse
//            unsigned int  x    - bit de interesse
// Saída:     -
/*********************************************************************************/
void bit_toggle(unsigned int ADDR, unsigned int x)
{
memory(ADDR,'w',1<<x,'x');
}
/********************************************/

/*********************************************************************************/
// Função:    bit_write_interval
// Descrição: Escreve num intervalo de bits usando a função "memory"
// Entrada:   int  ADDR             - endereço de memória de interesse
//            int  MSB              - bit mais significativo do intervalo
//            int  LSB              - bit menos significativo do intervalo
//            int  content          - conteúdo a ser escrito no intervalo
// Saída:     -
/*********************************************************************************/
void bit_write_interval(int ADDR, int MSB, int LSB, int content)
{
int i=0,j=0,before=0,after=0,and=0,or=0;

j = 1<<31;
for(i=31;i>MSB;i--)                             // Preenche com '1' à esquerda do intervalo de interesse
    {
    before = before | j;
    j = j/2;
    }

j = 1<<0;
for(i=0;i<LSB;i++)                              // Preenche com '1' à direita do intervalo de interesse
    {
    after = after | j;
    j = 2*j;
    }

and = (0xFFFFFFFF)&((content<<LSB)|after|before);  // Palavra a ser limpada
or = content<<LSB;                              // Palavra a ser setada

memory(ADDR,'w',and,'a');                       // Limpa os bits definidos como '0' em 'content'
memory(ADDR,'w',or,'o');                        // Seta os bits definidos como '1' em 'content'
}
/********************************************/

/*********************************************************************************/
// Função:    bit_read
// Descrição: Lê um bit usando a função "memory"
// Entrada:   int  ADDR             - endereço de memória de interesse
//            int  x                - bit de interesse
// Saída:     int                   - nivel lógico do bit de interesse                                 -
/*********************************************************************************/
int bit_read(int ADDR, int x)
{
return(((memory(ADDR,'r',0x0,'o'))&(1<<x))>>x);
}
/********************************************/

/*********************************************************************************/
// Função:    bit_read_interval
// Descrição: Lê um intervalo de bits usando a função "memory"
// Entrada:   int  ADDR             - endereço de memória de interesse
//            int  MSB              - bit mais significativo
//            int  LSB              - bit menos significativo
//            int  content          - conteúdo a ser escrito
// Saída:     int                   - resultado da leitura                                   -
/*********************************************************************************/
int bit_read_interval(int ADDR, int MSB, int LSB)
{
int i=0,j=0,before=0,after=0;

j = 1<<31;
for(i=31;i>MSB;i--)                                        // Preenche com '0' à esquerda do intervalo de interesse
    {
    before = before | j;
    j = j/2;
    }
before = ~before;

j = 1<<0;
for(i=0;i<LSB;i++)                                         // Preenche com '0' à direita do intervalo de interesse
    {
    after = after | j;
    j = 2*j;
    }
after = ~after;

return(((memory(ADDR,'r',0x0,'o'))&after&before)>>LSB);    // Elimina o conteúdo alheio ao intervalo de interesse
}
/********************************************/
