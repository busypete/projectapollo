// Máxima frequência de frame rate: 10,3 kHz (frame de 120 pontos: 10 pontos por período, 12 períodos por janela; algoritmo bastante linear)
// Oscilador com 555 funcionando
// Uma relação de 10x entre a frequência de amostragem e a frequência do sinal já garante uma medida aceitável
// Uma relação de 20x garante uma excelente medida.
// Próximo: criar uma variável FREQRATIO no frame_table.h para expressar essa relação (atualmente FREQRATIO = 9)
// Próximo: inserir uma entrada analógica que vai realizar a função do TIME_DIV, mudando, portanto, a frequência de amostragem

#include <stdint.h>
#include <stdlib.h>
#include <pru_cfg.h>
#include "resource_table_empty.h"
#include "adress_table.h"
#include "frame_table.h"

// Escopo de funções

// Hardware
extern int button_state(void);
extern void debounce(void);
extern int led_read(void);
extern void led_write(int i);
extern void led_toggle(void);
/********************************************/

// Memory
extern int memory(int ADDR, char acess, int content, char logic);
extern void bit_clear(int ADDR, int x);
extern void bit_set(int ADDR, int x);
extern void bit_write_interval(int ADDR, int MSB, int LSB, int content);
extern int bit_read(int ADDR, int x);
extern int bit_read_interval(int ADDR, int MSB, int LSB);
/********************************************/

// Frame
extern frame_read(unsigned int ADDR, unsigned int length);
extern void frame_write(int* vector, unsigned int ADDR, unsigned int length);
extern int compare_vector(int* vector1, int* vector2, unsigned int length);
extern int* frame_maker(unsigned int ADDR, unsigned int length);
extern int freq_counter(int* vector, unsigned int sample_rate, int trigger_level, unsigned int length);
/********************************************/

// Config
extern void config(void);
/********************************************/

int rx[FRAME_SIZE];                             // Variável global para capturar o frame da conversão AD (alocação dinâmica deu ruim)

void main(void)
{
while(1)
    {
    frame_read(PRU0_BUFFER,FRAME_SIZE);                                         // Captura o frame da conversão AD
    frame_write(rx,PRU1_BUFFER,FRAME_SIZE);                                     // Envia o frame tratado para o ARM
    int freq = freq_counter(rx,SAMPLE_RATE,TRIGGER_LEVEL,FRAME_SIZE);           // Determina a frequência do frame recém-capturado
    memory(CONTROL_BUFFER,'w',freq,'k');                                        // Envia a frequência para o ARM
    led_toggle();                                                               // Debug
    }
}
