// Controle do frame
#define PRU_WRITE           0xAA
#define PRU_READ            0xBB
#define ARM_WRITE           0xCC
#define ARM_READ            0xDD
#define LOCK                0xEE

// Parâmetros do scope
#define TRIGGER_LEVEL       300                                     // Nível do 'zero-crossing'
#define SAMPLE_RATE         7000                                    // Frequência de amostragem atual do sinal de entrada

// Dimensões do frame
#define SAMPLE_PER_PERIOD   12                                      // Número de amostras por período
#define PERIOD_PER_FRAME    10                                      // Número de períodos por frame (será uma função de TIME/DIV)
#define FRAME_SIZE          SAMPLE_PER_PERIOD*PERIOD_PER_FRAME      // Número de amostras por frame

