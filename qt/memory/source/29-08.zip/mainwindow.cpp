#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTimer>

extern QString str1;
extern QString str2;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QTimer *tick = new QTimer(this);
    connect(tick, SIGNAL(timeout()),this, SLOT(tick_timeout()));
    tick->stop();
    tick->start(2000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pbClose_pressed()
{
QString str1 = "Hello World";
QString str2 = "Olá mundo";
if((QString::compare(ui->lbMessage->text(),str1,Qt::CaseSensitive))==0)   ui->lbMessage->setText(str2);
else if((QString::compare(ui->lbMessage->text(),str2,Qt::CaseSensitive))==0)   ui->lbMessage->setText(str1);
}

void MainWindow::tick_timeout()
{
FILE* fd;
static int i = 0;
if(i==1) fd = fopen("/home/bruno/Downloads/oi.txt","w");
else fd = fopen("/home/bruno/Downloads/oi.txt","a");
if(i<=9) fprintf(fd,"eita\n");
else fclose(fd);
if((QString::compare(ui->pbClose->text(),str1,Qt::CaseSensitive))==0)   ui->pbClose->setText(str2);
else if((QString::compare(ui->pbClose->text(),str2,Qt::CaseSensitive))==0)   ui->pbClose->setText(str1);
i++;
}
