#include "mainwindow.h"
#include "addres_table.h"

#include <QApplication>

// Memory
extern "C" int memory(int ADDR, char acess, int content, char logic);
extern "C" void bit_clear(int ADDR, int x);
extern "C" void bit_set(int ADDR, int x);
extern "C" void bit_write_interval(int ADDR, int MSB, int LSB, int content);
extern "C" int bit_read(int ADDR, int x);
extern "C" int bit_read_interval(int ADDR, int MSB, int LSB);
/********************************************/

QString str1 = "Eita";
QString str2 = "stomp";

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}


