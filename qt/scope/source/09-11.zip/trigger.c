#include "encoder.h"
#include "addres_table.h"
#include "/home/bruno/ti-processor-sdk-linux-am335x-evm-04.02.00.09/linux-devkit/sysroots/armv7ahf-neon-linux-gnueabi/usr/include/stdlib.h"

int trigger_detect(double first_value, double second_value, double trigger_level)
{
if((first_value<trigger_level)&&(second_value>trigger_level)) return(1);
else return(0);
}
