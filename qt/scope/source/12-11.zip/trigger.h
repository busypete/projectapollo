// Sistema de trigger
#define TRIGGER_LEVEL1      0.3                                 // Limiar de disparo por borda, em volts, do canal 1
#define TRIGGER_LEVEL2      0                                   // Limiar de disparo por borda, em volts, do canal 2
#define OVERSHOOT           1.25                                // Fator pelo qual o número de pontos usual é multiplicado
                                                                // de forma a existir uma folga para o deslocamento

