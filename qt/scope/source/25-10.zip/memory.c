#include "/home/bruno/ti-processor-sdk-linux-am335x-evm-04.02.00.09/linux-devkit/sysroots/armv7ahf-neon-linux-gnueabi/usr/include/stdlib.h"
#include "/home/bruno/ti-processor-sdk-linux-am335x-evm-04.02.00.09/linux-devkit/sysroots/armv7ahf-neon-linux-gnueabi/usr/include/stdio.h"
#include "/home/bruno/ti-processor-sdk-linux-am335x-evm-04.02.00.09/linux-devkit/sysroots/armv7ahf-neon-linux-gnueabi/usr/include/fcntl.h"
#include "/home/bruno/ti-processor-sdk-linux-am335x-evm-04.02.00.09/linux-devkit/sysroots/armv7ahf-neon-linux-gnueabi/usr/include/unistd.h"
#include "/home/bruno/ti-processor-sdk-linux-am335x-evm-04.02.00.09/linux-devkit/sysroots/armv7ahf-neon-linux-gnueabi/usr/include/sys/mman.h"

#define MAP_SIZE 4096UL
#define MAP_MASK (MAP_SIZE - 1)

/*********************************************************************************/
/*  Função:     memory
    Descrição:  Acesso (leitura e escrita) a registros do AM335x utilizando o driver
                /dev/mem. Os argumentos 'content' e 'logic' não possuem nenhum efeito
                caso acess = 'r'.
    Entrada:    unsigned int  ADDR    - endereço de memória de interesse
                char acess            - 'r': leitura, 'w': escrita
                unsigned int  content - conteúdo a ser escrito no endereço ADDR
                char logic            - 'k': *ADDR = content
                                      - 'o': *ADDR |= content
                                      - 'a': *ADDR = *ADDR & content
                                      - 'x': *ADDR = *ADDR ^ content
    Saída:      unsigned int          - resultado da leitura */
/*********************************************************************************/
unsigned int memory(unsigned int ADDR, char acess, unsigned int content, char logic)
{
int fd;
void *map_base, *virt_addr;
unsigned int read_result;
off_t target;

target = ADDR;
fd = open("/dev/mem", O_RDWR | O_SYNC);
map_base = mmap(0, MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, target & ~MAP_MASK);
virt_addr = map_base + (target & MAP_MASK);
read_result = *((unsigned long *) virt_addr);

if(acess == 'r') read_result = *((unsigned long *) virt_addr);
else if(acess == 'w')
    {
    if(logic == 'k') *((unsigned long *) virt_addr) = content;
    else if(logic == 'o') *((unsigned long *) virt_addr) |= content;
    else if(logic == 'a') *((unsigned long *) virt_addr) &= content;
    else if(logic == 'x') *((unsigned long *) virt_addr) ^= content;
    read_result = *((unsigned long *) virt_addr);
    }

close(fd);
munmap(map_base,MAP_SIZE);
return(read_result);
}
/********************************************/

/*********************************************************************************/
/*  Função:     bit_clear
    Descrição:  Limpa um bit usando a função "memory"
    Entrada:    unsigned int  ADDR - endereço de memória de interesse
                unsigned int  x    - bit de interesse
    Saída:      - */
/*********************************************************************************/
void bit_clear(unsigned int ADDR, unsigned int x)
{
memory(ADDR,'w',(~(1<<x)),'a');
}
/*********************************************************************************/

/*********************************************************************************/
/*  Função:     bit_set
    Descrição:  Seta um bit usando a função "memory"
    Entrada:    unsigned int  ADDR - endereço de memória de interesse
                unsigned int  x    - bit de interesse
    Saída:      - */
/*********************************************************************************/
void bit_set(unsigned int ADDR, unsigned int x)
{
memory(ADDR,'w',(1<<x),'o');
}
/*********************************************************************************/

/*********************************************************************************/
/*  Função:     bit_toggle
    Descrição:  Inverte um bit usando a função "memory"
    Entrada:    unsigned int  ADDR - endereço de memória de interesse
                unsigned int  x    - bit de interesse
    Saída:      -   */
/*********************************************************************************/
void bit_toggle(unsigned int ADDR, unsigned int x)
{
memory(ADDR,'w',1<<x,'x');
}
/********************************************/

/*********************************************************************************/
/*  Função:     bit_write_interval
    Descrição:  Escreve num intervalo de bits usando a função "memory"
    Entrada:    unsigned int  ADDR    - endereço de memória de interesse
                unsigned int  MSB     - bit mais significativo
                unsigned int  LSB     - bit menos significativo
                unsigned int  content - conteúdo a ser escrito
    Saída:      - */
/*********************************************************************************/
void bit_write_interval(unsigned int ADDR, unsigned int MSB, unsigned int LSB, unsigned int content)
{
unsigned int i=0,j=0,before=0,after=0,and=0,or=0;

j = 1<<31;
for(i=31;i>MSB;i--)                             // Preenche com '1' à esquerda do intervalo de interesse
    {
    before = before | j;
    j = j/2;
    }

j = 1<<0;
for(i=0;i<LSB;i++)                              // Preenche com '1' à direita do intervalo de interesse
    {
    after = after | j;
    j = 2*j;
    }

and = (0xFFFFFFFF)&((content<<LSB)|after|before);  // Palavra a ser limpada
or = content<<LSB;                              // Palavra a ser setada

memory(ADDR,'w',and,'a');                       // Limpa os bits definidos como '0' em 'content'
memory(ADDR,'w',or,'o');                        // Seta os bits definidos como '1' em 'content'
}
/*********************************************************************************/

/*********************************************************************************/
/*  Função:     bit_read
    Descrição:  Lê um bit usando a função "memory"
    Entrada:    unsigned int  ADDR    - endereço de memória de interesse
                unsigned int  x       - bit de interesse
    Saída:      unsgined int          - nivel lógico do bit */
/*********************************************************************************/
unsigned int bit_read(unsigned int ADDR, unsigned int x)
{
return(((memory(ADDR,'r',0x0,'o'))&(1<<x))>>x);
}
/*********************************************************************************/

/*********************************************************************************/
/*  Função:     bit_read_interval
    Descrição:  Lê um intervalo de bits usando a função "memory"
    Entrada:    unsigned int  ADDR    - endereço de memória de interesse
                unsigned int  MSB     - bit mais significativo
                unsigned int  LSB     - bit menos significativo
                unsigned int  content - conteúdo a ser escrito
    Saída:      unsgined int          - resultado da leitura  */
/*********************************************************************************/
unsigned int bit_read_interval(unsigned int ADDR, unsigned int MSB, unsigned int LSB)
{
unsigned int i=0,j=0,before=0,after=0;

j = 1<<31;
for(i=31;i>MSB;i--)                                        // Preenche com '0' à esquerda do intervalo de interesse
    {
    before = before | j;
    j = j/2;
    }
before = ~before;

j = 1<<0;
for(i=0;i<LSB;i++)                                         // Preenche com '0' à direita do intervalo de interesse
    {
    after = after | j;
    j = 2*j;
    }
after = ~after;

return(((memory(ADDR,'r',0x0,'o'))&after&before)>>LSB);    // Elimina o conteúdo alheio ao intervalo de interesse
}
/*********************************************************************************/
