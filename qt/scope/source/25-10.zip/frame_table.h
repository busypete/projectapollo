// Controle do frame
#define QTBUSY              0xCC                                // Qt ocupado
#define QTLAZY              0xDD                                // Qt livre

// Dimensões do frame
#define SAMPLE_PER_PERIOD   12                                  // Número de amostras por período
#define PERIOD_PER_FRAME    10                                  // Número de períodos por frame (será uma função de TIME/DIV)
#define FRAME_SIZE          SAMPLE_PER_PERIOD*PERIOD_PER_FRAME  // Número de amostras por frame

// Parâmetros de desempenho
#define MAX_SAMPLE_RATE     300000                              // Máxima frequência de amostragem por canal
#define FRAME_RATE          16                                  // Frequência de atualização do frame

// Eixo X
#define MAG_X_MAX           1                                   // Magntidude máxima, em segundos, do eixo X
#define MAG_X_MIN          (FRAME_SIZE*1.0)/(MAX_SAMPLE_RATE*1.0)          // Magnituda mínima, em segundos, do eixo X
#define MAG_X_DEFAULT       0.002                               // Magnitude padrão do eixo Y
#define MAG_X_FACTOR        2                                   // Fator pelo qual a magnitude do eixo X é manipulada

// Eixo Y
#define MAG_Y_MAX           200                                 // Valor máximo, em volts, do eixo Y
#define MAG_Y_MIN           0.02                                // Valor mínimo, em volts, do eixo Y
#define MAG_Y_DEFAULT       3                                   // Valor padrão do eixo Y
#define MAG_Y_MAG           2                                   // Razão pela qual o eixo Y é multiplicado ou dividido
#define POS_Y_MAX           10                                  // Posição vertical máxima do eixo Y
#define POS_Y_MIN           -10                                 // Posição vertical mínima do eixo Y
#define POS_Y_DEFAULT       0                                   // Posição vertical padrão do eixo Y
#define POS_Y_INC           1                                   // Incremento na posição vertical do eixo Y


