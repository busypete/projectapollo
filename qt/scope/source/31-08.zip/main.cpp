#include "mainwindow.h"
#include "addres_table.h"

#include <QApplication>
#include "QtCharts"

QLineSeries *ch1 = new QLineSeries();
QLineSeries *ch2 = new QLineSeries();

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}


