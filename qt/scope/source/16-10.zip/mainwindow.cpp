﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "addres_table.h"
#include "frame_table.h"
#include "encoder.h"

#include <QTimer>
#include <QtMath>
#include "QtCharts"
#include <QList>

QLineSeries *ch1 = new QLineSeries();
QLineSeries *ch2 = new QLineSeries();

// Memory
extern "C" unsigned int memory(unsigned int ADDR, char acess, unsigned int content, char logic);
extern "C" void bit_toggle(unsigned int ADDR, unsigned int x);
/********************************************/

// Encoder
extern "C" int get_change(int* current_serial_data, int* last_serial_data);
extern "C" int* get_serial_data(void);
extern "C" int get_direction(int encoder, int* current_serial_data, int* last_serial_data);
/********************************************/

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Timer
    QTimer *frame_tick = new QTimer(this);
    frame_tick->setTimerType(Qt::PreciseTimer);
    connect(frame_tick, SIGNAL(timeout()),this, SLOT(frame_tick_timeout()));
    frame_tick->stop();
    frame_tick->start(40);

    QTimer *encoder_tick = new QTimer(this);
    encoder_tick->setTimerType(Qt::PreciseTimer);
    connect(encoder_tick, SIGNAL(timeout()),this, SLOT(encoder_tick_timeout()));
    encoder_tick->stop();
    encoder_tick->start(0);

    // Chart
    ui->chart = new QChart();
    ui->chart->setTheme(QChart::ChartThemeDark);
    ui->chart->addSeries(ch1);
    ui->chart->addSeries(ch2);
    ch1->setColor("yellow");
    ch1->setName("CH1");
    ch2->setColor("blue");
    ch2->setName("CH2");
    ui->chart->createDefaultAxes();
    ui->chart->axisX()->setTitleText("Time (s)");
    ui->chart->axisX()->setRange(0,(FRAME_SIZE*1.0)/(4.0*SAMPLE_RATE));
    ui->chart->axisY()->setTitleText("Voltage (V)");
    ui->chart->axisY()->setRange(-2,2);

    // ChartView
    ui->chartView = new QChartView(ui->chart,ui->centralWidget);
    ui->chartView->setGeometry(QRect(0,0,800,480));
    ui->chartView->setRenderHint(QPainter::Antialiasing,true);
    ui->chartView->show();

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::frame_tick_timeout()
{
// Qt busy
memory(CONTROL_BUFFER,'w',QTBUSY,'k');

// Capture data
unsigned int i = 0;
double* time = new double[FRAME_SIZE];
double* voltage1 = new double[FRAME_SIZE];
double* voltage2 = new double[FRAME_SIZE];
QVector<QPointF> data1;
QVector<QPointF> data2;

for(i=0;i<FRAME_SIZE;i++)
    {
    time[i] = ((1.0*i)/(SAMPLE_RATE*1.0));
    voltage1[i] = ((memory(ARM1_BUFFER+4*i,'r',0x00,'o')*1.0)/(4096.0))*1.8;
    voltage2[i] = 1.5*qSin(2.0*M_PI*((SAMPLE_RATE*1.0)/(FRAME_SIZE*1.0))*(time[i]));
    data1 << QPointF(time[i],voltage1[i]);
    data2 << QPointF(time[i],voltage2[i]);
    }

// Chart update
ch1->replace(data1);
ch2->replace(data2);

// Qt lazy
memory(CONTROL_BUFFER,'w',QTLAZY,'k');
}

void MainWindow::encoder_tick_timeout()
{
static int number_of_serial_captures = 0;
static int time_div = 1;
static double volt_div = 2.0;
int j = 0;
static int* last_serial_data = static_cast<int*>((malloc(NUMBER_OF_INPUTS*sizeof(int))));
static int* current_serial_data = static_cast<int*>((malloc(NUMBER_OF_INPUTS*sizeof(int))));

if(number_of_serial_captures>=2)
    {
    if(get_change(current_serial_data,last_serial_data))
        {
        if(get_direction(1,current_serial_data,last_serial_data)==0) time_div++;
        else if(get_direction(1,current_serial_data,last_serial_data)==1)
            {
            if(time_div>=2) time_div--;
            else time_div = 1;
            }
        ui->chart->axisX()->setRange(0,(FRAME_SIZE*time_div*1.0)/(4.0*SAMPLE_RATE));
        if(get_direction(2,current_serial_data,last_serial_data)==0) volt_div = volt_div + 0.2;
        else if(get_direction(2,current_serial_data,last_serial_data)==1)
            {
            if(volt_div>=0.4) volt_div = volt_div - 0.2;
            else volt_div = 0.2;
            }
        ui->chart->axisY()->setRange(-volt_div,volt_div);
        }
    }
else number_of_serial_captures++;
for(j=0;j<NUMBER_OF_INPUTS;j++) last_serial_data[j] = current_serial_data[j];
free(current_serial_data);
current_serial_data = get_serial_data();
}

