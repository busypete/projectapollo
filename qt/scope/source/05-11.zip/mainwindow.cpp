﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "addres_table.h"
#include "frame_table.h"
#include "encoder.h"

#include <QTimer>
#include <QtMath>
#include "QtCharts"
#include <QList>

QLineSeries *ch1 = new QLineSeries();
QLineSeries *ch2 = new QLineSeries();
QVector<QPointF> raw_data1;
QVector<QPointF> raw_data2;
QVector<QPointF> nice_data1(POINTS_PER_FRAME);
QVector<QPointF> nice_data2(POINTS_PER_FRAME);
int nice_update_request = 0, raw_update_request = 0;
double time_div = static_cast<double>(MAG_X_DEFAULT);
double vertical_position = static_cast<double>(POS_Y_DEFAULT);
double* time_vector = new double[FRAME_SIZE];
double last_time = 0;

// Memory
extern "C" unsigned int memory(unsigned int ADDR, char acess, unsigned int content, char logic);
extern "C" void bit_toggle(unsigned int ADDR, unsigned int x);
/********************************************/

// Encoder
extern "C" int* get_serial_data(void);
extern "C" int get_change(int* current_serial_data, int* last_serial_data);
extern "C" int get_sweep_change(int* current_serial_data, int* last_serial_data);
extern "C" int get_click(int encoder, int* serial_data);
extern "C" int get_direction(int encoder, int* current_serial_data, int* last_serial_data);
extern "C" int get_smooth_direction(int* vector, int length);
/********************************************/

// IEP
extern "C" void set_wave_IEP(int freq);
/********************************************/

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Timer
    QTimer *frame_tick = new QTimer(this);
    frame_tick->setTimerType(Qt::PreciseTimer);
    connect(frame_tick, SIGNAL(timeout()),this, SLOT(frame_tick_timeout()));
    frame_tick->stop();
    frame_tick->start(1000/FRAME_RATE);

    QTimer *encoder_tick = new QTimer(this);
    encoder_tick->setTimerType(Qt::PreciseTimer);
    connect(encoder_tick, SIGNAL(timeout()),this, SLOT(encoder_tick_timeout()));
    encoder_tick->stop();
    encoder_tick->start(1000/ENCODER_RATE);

    QTimer *data_tick = new QTimer(this);
    data_tick->setTimerType(Qt::PreciseTimer);
    connect(data_tick, SIGNAL(timeout()),this, SLOT(data_tick_timeout()));
    data_tick->stop();
    data_tick->start(0);

    // Chart
    ui->chart = new QChart();
    ui->chart->setTheme(QChart::ChartThemeDark);
    ui->chart->addSeries(ch1);
    ui->chart->addSeries(ch2);
    ch1->setColor("yellow");
    ch1->setName("CH1");
    ch2->setColor("blue");
    ch2->setName("CH2");
    ui->chart->createDefaultAxes();
    ui->chart->axisX()->setTitleText("Time (s)");
    ui->chart->axisX()->setRange(0,MAG_X_DEFAULT);
    ui->chart->axisY()->setTitleText("Voltage (V)");
    ui->chart->axisY()->setRange(-MAG_Y_DEFAULT,MAG_Y_DEFAULT);

    // ChartView
    ui->chartView = new QChartView(ui->chart,ui->centralWidget);
    ui->chartView->setGeometry(QRect(0,0,800,480));
    ui->chartView->setRenderHint(QPainter::Antialiasing,true);
    ui->chartView->show();

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::frame_tick_timeout()
{
if(raw_update_request==1)
    {
    ch1->replace(raw_data1);
    ch2->replace(raw_data2);
    raw_data1.clear();
    raw_data2.clear();
    raw_update_request = 0;
    }
else if(nice_update_request==1)
    {
    ch1->replace(nice_data1);
    ch2->replace(nice_data2);
    raw_data1.clear();
    raw_data2.clear();
    nice_update_request = 0;
    }

//if(update_request==1)
//    {
//    ch1->replace(raw_data1);
//    ch2->replace(raw_data2);
//    raw_data1.clear();
//    raw_data2.clear();
//    update_request = 0;
//    }
}

void MainWindow::encoder_tick_timeout()
{
static int number_of_serial_captures = 0, number_of_direction_samples = 0;
int j = 0;
static double volt_div = static_cast<double>(MAG_Y_DEFAULT);
static int* last_serial_data = static_cast<int*>((malloc(NUMBER_OF_INPUTS*sizeof(int))));
static int* current_serial_data = static_cast<int*>((malloc(NUMBER_OF_INPUTS*sizeof(int))));
static int* direction1 = static_cast<int*>((malloc(NUMBER_OF_AVG*sizeof(int))));
static int* direction2 = static_cast<int*>((malloc(NUMBER_OF_AVG*sizeof(int))));
static int* direction3 = static_cast<int*>((malloc(NUMBER_OF_AVG*sizeof(int))));
static int* direction4 = static_cast<int*>((malloc(NUMBER_OF_AVG*sizeof(int))));

if(number_of_serial_captures>=2)
    {
    if(get_change(current_serial_data,last_serial_data))
        {
        if(get_sweep_change(current_serial_data,last_serial_data))
            {
            direction1[number_of_direction_samples] = get_direction(1,current_serial_data,last_serial_data);
            direction2[number_of_direction_samples] = get_direction(2,current_serial_data,last_serial_data);
            direction3[number_of_direction_samples] = get_direction(3,current_serial_data,last_serial_data);
            direction4[number_of_direction_samples] = get_direction(4,current_serial_data,last_serial_data);
            number_of_direction_samples++;
            if(number_of_direction_samples>=NUMBER_OF_AVG)
                {
                number_of_direction_samples = 0;
                if(get_smooth_direction(direction1,NUMBER_OF_AVG)==-1)
                    {
                    if(time_div<=((MAG_X_MAX*1.0)/(MAG_X_FACTOR*1.0))) time_div = time_div*MAG_X_FACTOR;
                    else time_div = MAG_X_MAX;
//                    set_wave_IEP(static_cast<int>((FRAME_SIZE*1.0)/(time_div)));
                    ui->chart->axisX()->setRange(0,time_div);
                    }
                else if(get_smooth_direction(direction1,NUMBER_OF_AVG)==1)
                    {
                    if(time_div>=(MAG_X_MIN*MAG_X_FACTOR)) time_div = time_div/(MAG_X_FACTOR*1.0);
                    else time_div = MAG_X_MIN;
//                    set_wave_IEP(static_cast<int>((FRAME_SIZE*1.0)/(time_div)));
                    ui->chart->axisX()->setRange(0,time_div);
                    }
                if(get_smooth_direction(direction2,NUMBER_OF_AVG)==-1)
                    {
                    if(volt_div<=((MAG_Y_MAX*1.0)/(MAG_Y_MAG*1.0))) volt_div = volt_div*MAG_Y_MAG;
                    else volt_div = MAG_Y_MAX;
                    ui->chart->axisY()->setRange(-volt_div,volt_div);
                    }
                else if(get_smooth_direction(direction2,NUMBER_OF_AVG)==1)
                    {
                    if(volt_div>=(MAG_Y_MIN*MAG_Y_MAG)) volt_div = volt_div/(MAG_Y_MAG*1.0);
                    else volt_div = MAG_Y_MIN;
                    ui->chart->axisY()->setRange(-volt_div,volt_div);
                    }
                if(get_smooth_direction(direction3,NUMBER_OF_AVG)==-1)
                    {
                    if(vertical_position>=((POS_Y_MIN+POS_Y_INC)*1.0)) vertical_position = vertical_position - POS_Y_INC*1.0;
                    else vertical_position = POS_Y_MIN;
                    }
                else if(get_smooth_direction(direction3,NUMBER_OF_AVG)==1)
                    {
                    if(vertical_position<=((POS_Y_MAX-POS_Y_INC)*1.0)) vertical_position = vertical_position + POS_Y_INC*1.0;
                    else vertical_position = POS_Y_MAX;
                    }
                }
            }
        else
            {
            number_of_direction_samples = 0;
            }
        }
        
    }
else number_of_serial_captures++;
for(j=0;j<NUMBER_OF_INPUTS;j++) last_serial_data[j] = current_serial_data[j];
free(current_serial_data);
current_serial_data = get_serial_data();
}

void MainWindow::data_tick_timeout()
{
// Variables
int j = 0;
double* voltage1 = new double[FRAME_SIZE];
double* voltage2 = new double[FRAME_SIZE];
unsigned int i = 0, number_of_total_points = 0, overwrite_factor = 0;

if((nice_update_request==0)&&(raw_update_request==0))
    {
    // Qt busy
    memory(CONTROL_BUFFER,'w',QTBUSY,'k');

    // Capture data
    for(i=0;i<FRAME_SIZE;i++)
        {
        time_vector[i] = last_time + ((i*1.0)/(SAMPLE_RATE*1.0));
        voltage1[i] = ((memory(ARM1_BUFFER+4*i,'r',0x00,'o')*1.0)/(4096.0))*1.8 + vertical_position;
        voltage2[i] = 1.5*qSin(2.0*M_PI*1000*(time_vector[i])) + vertical_position;
        raw_data1 << QPointF(time_vector[i],voltage1[i]);
        raw_data2 << QPointF(time_vector[i],voltage2[i]);
        }

    // Qt lazy
    memory(CONTROL_BUFFER,'w',QTLAZY,'k');

    // Update series
    last_time = time_vector[FRAME_SIZE-1];
    if(last_time>=time_div)
        {
        number_of_total_points = static_cast<unsigned int>(raw_data1.size());
        if(number_of_total_points>POINTS_PER_FRAME)
            {
            overwrite_factor = (number_of_total_points)/(POINTS_PER_FRAME);
            for(i=0;i<number_of_total_points;i=i+overwrite_factor)
                {
                nice_data1[static_cast<int>(j)] = raw_data1.at(static_cast<int>(i));
                nice_data2[static_cast<int>(j)] = raw_data2.at(static_cast<int>(i));
                if(j<(POINTS_PER_FRAME-1)) j++;
                }
            j = 0;
            nice_update_request = 1;
            }
        else raw_update_request = 1;
//        update_request = 1;
        last_time = 0;
        }
    }
}
