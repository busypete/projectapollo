// Parâmetros
/********************************************/
#define NUMBER_OF_INPUTS    16                                  // Número de dados no vetor serial
#define NUMBER_OF_AVG       5                                   // Número de médias para definir o sentido de giro
#define THRESHOLD           0.4                                 // Sensibilidade para definir sentido de giro
#define ENCODER_RATE        200                                 // Frequência, em hertz, de leitura dos encoders
/********************************************/

// Pinagem
/********************************************/
#define CP                  2                                   // Clock pulse
#define PL                  3                                   // Parallel load
#define SD                  4                                   // Serial data
#define ENC1_SW             11                                  // Chave do ENCODER 1
#define ENC2_SW             10                                  // Chave do ENCODER 2
#define ENC3_SW             9                                   // Chave do ENCODER 3
#define ENC4_SW             8                                   // Chave do ENCODER 4
#define ENC1_A              7                                   // Sinal A do ENCODER 1
#define ENC1_B              6                                   // Sinal B do ENCODER 1
#define ENC2_A              5                                   // Sinal A do ENCODER 2
#define ENC2_B              4                                   // Sinal B do ENCODER 2
#define ENC3_A              3                                   // Sinal A do ENCODER 3
#define ENC3_B              2                                   // Sinal B do ENCODER 3
#define ENC4_A              1                                   // Sinal A do ENCODER 4
#define ENC4_B              0                                   // Sinal B do ENCODER 4
/********************************************/
