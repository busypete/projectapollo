#include "/home/bruno/ti-processor-sdk-linux-am335x-evm-04.02.00.09/linux-devkit/sysroots/armv7ahf-neon-linux-gnueabi/usr/include/stdlib.h"
#include "/home/bruno/ti-processor-sdk-linux-am335x-evm-04.02.00.09/linux-devkit/sysroots/armv7ahf-neon-linux-gnueabi/usr/include/stdio.h"

/*********************************************************************************/
/* Função:    compare_vector
   Descrição: Compara dois vetores. Necessariamente, eles devem possuir a mesma dimensão
   Entrada:   char* vector1         - operando 1
              char* vector1         - operando 2
              unsigned int length   - tamanho dos vetores
   Saída:     int result       0:   - vetores diferentes
                               1:   - vetores iguais */
/*********************************************************************************/
int compare_vector(const char* vector1, const char* vector2, unsigned int length)
{
unsigned int i,match = 0;                       // Índice de iteração e número de matches
for(i=0;i<length;i++)                           // Aplica a restrição de igual a cada posição dos vetores
    {
    if(vector1[i]==vector2[i]) match++;         // Incrementa o acumulador de matches
    else break;                                 // Quebra o laço quando encontrar qualquer diferença
    }
if(match==length) return(1);                    // Vetores idênticos
else return(0);
}
/********************************************/

/*********************************************************************************/
/* Função:    print_channel_to_file
   Descrição: Imprime um vetor de inteiros em um arquivo
   Entrada:   int* vector1              - vetor 'x' a ser impresso, caso mode = "xy"
              int* vector2              - vetor 'y' a ser impresso
              unsigned int length       - tamanho do vetor a ser impresso
              unsigned int sample_rate  - frequência de amostragem do canal
              char* filename            - nome do arquivo a ser criado
              char* mode                - "xy": plota vector1 versus vector2
                                        - "ty": plota tempo versus vector2
// Saída:     - */
/*********************************************************************************/
void print_channel_to_file(int* vector1, int* vector2, unsigned int length, unsigned int sample_rate, const char* filename, const char* mode)
{
unsigned int i;                                                         // Índice de iteração
double step = (double)((1000.0)/(sample_rate*1.0));                     // Passo do vetor de tempo
double* time = (double*)(malloc(length*sizeof(double)));                // Vetor de tempo
double* voltage1 = (double*)(malloc(length*sizeof(double)));            // Vetor de tensões do vector1
double* voltage2 = (double*)(malloc(length*sizeof(double)));            // Vetor de tensões do vector2
char aux1[] = "ty";                                                     // String de modo "xy"
char aux2[] = "xy";                                                     // String de modo "ty"
FILE* fd;                                                               // Ponteiro de arquivo
fd = fopen(filename,"w");                                               // Abre o arquivo limpando seu conteúdo
if(compare_vector(aux1,mode,sizeof(aux1)/sizeof(char)))
    {
    for(i=0;i<length;i++)                                               // Modo "ty"
        {
        time[i] = step*i;                                               // Cria cada posição do vetor de tempo
        voltage2[i] = ((vector2[i]*1.0)/(4096*1.0))*1.8;                // Cria cada posição do vetor voltage2
        fprintf(fd,"%.2f %.2f\n",time[i],voltage2[i]);                  // Imprime o par ordenado tempo x voltage2
        }
    }
else if(compare_vector(aux2,mode,sizeof(aux2)/sizeof(char)))            // Modo "xy"
    {
    for(i=0;i<length;i++)
        {
        voltage1[i] = ((vector1[i]*1.0)/(4096*1.0))*(1.8);              // Cria cada posição do vetor voltage1
        voltage2[i] = ((vector2[i]*1.0)/(4096*1.0))*(1.8);              // Cria cada posição do vetor voltage2
        fprintf(fd,"%.2f %.2f\n",voltage1[i],voltage2[i]);              // Imprime o par ordenado voltage1 x voltage2
        }
    }
fclose(fd);                                                             // Fecha o arquivo
}
/*********************************************************************************/

