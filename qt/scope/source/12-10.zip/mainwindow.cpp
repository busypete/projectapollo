#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "addres_table.h"
#include "frame_table.h"

#include <QTimer>
#include <QtMath>
#include "QtCharts"

QLineSeries *ch1 = new QLineSeries();
QLineSeries *ch2 = new QLineSeries();

// Memory
extern "C" unsigned int memory(unsigned int ADDR, char acess, unsigned int content, char logic);
extern "C" void bit_toggle(unsigned int ADDR, unsigned int x);
/********************************************/

// File
extern "C" void print_channel_to_file(int* vector1, int* vector2, unsigned int data_length, unsigned int sample_rate, const char* filename, const char* mode);
/********************************************/

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Timer
    QTimer *tick = new QTimer(this);
    tick->setTimerType(Qt::PreciseTimer);
    connect(tick, SIGNAL(timeout()),this, SLOT(tick_timeout()));
    tick->stop();
    tick->start(16);

    // Chart
    ui->chart = new QChart();
    ui->chart->addSeries(ch1);
    ui->chart->addSeries(ch2);
    ui->chart->setTheme(QChart::ChartThemeDark);
    ch1->setColor("yellow");
    ch2->setColor("blue");
    ch1->setName("CH1");
    ch2->setName("CH2");
    ui->chart->createDefaultAxes();
    ui->chart->axisX()->setTitleText("Time (s)");
    ui->chart->axisY()->setTitleText("Voltage (V)");
    ui->chart->axisY()->setRange(-2,2);

    // ChartView
    ui->chartView = new QChartView(ui->chart,ui->centralWidget);
    ui->chartView->setGeometry(QRect(0,0,800,480));
    ui->chartView->setRenderHint(QPainter::Antialiasing);
    ui->chartView->show();

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::tick_timeout()
{
// Qt busy
memory(CONTROL_BUFFER,'w',QTBUSY,'k');

// Capture data
unsigned int i;
float* time = new float[FRAME_SIZE];
float* voltage1 = new float[FRAME_SIZE];
float* voltage2 = new float[FRAME_SIZE];
ch1->clear();
ch2->clear();

for(i=0;i<FRAME_SIZE;i++)
    {
    time[i] = ((1.0f*i)/(SAMPLE_RATE*1.0f));
    voltage1[i] = ((memory(ARM1_BUFFER+4*i,'r',0x00,'o')*1.0f)/(4096.0f))*1.8f;
    voltage2[i] = static_cast<float>(1.5*qSin(2.0*M_PI*((SAMPLE_RATE*1.0)/(FRAME_SIZE*1.0))*static_cast<double>(time[i])));
    ch1->append(static_cast<double>(time[i]),static_cast<double>(voltage1[i]));
    ch2->append(static_cast<double>(time[i]),static_cast<double>(voltage2[i]));
    }

// Chart update
ui->chart->axisX()->setRange(0,time[FRAME_SIZE-1]);

// Qt lazy
memory(CONTROL_BUFFER,'w',QTLAZY,'k');
}
