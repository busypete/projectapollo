#include "encoder.h"
#include "addres_table.h"
#include "/home/bruno/ti-processor-sdk-linux-am335x-evm-04.02.00.09/linux-devkit/sysroots/armv7ahf-neon-linux-gnueabi/usr/include/stdlib.h"

extern void bit_clear(unsigned int ADDR, unsigned int x);
extern void bit_set(unsigned int ADDR, unsigned int x);
extern unsigned int bit_read(unsigned int ADDR, unsigned int x);

/*********************************************************************************/
/* Função:    compare_vector
   Descrição: Compara dois vetores. Necessariamente, eles devem possuir a mesma dimensão
   Entrada:   int* vector1          - operando 1
              int* vector1          - operando 2
              unsigned int length   - tamanho dos vetores
   Saída:     int              0:   - vetores diferentes
                               1:   - vetores iguais */
/*********************************************************************************/
int compare_vector(int* vector1, int* vector2, int length)
{
int i,match = 0;                                // Índice de iteração e número de matches
for(i=0;i<length;i++)                           // Aplica a restrição de igual a cada posição dos vetores
    {
    if(vector1[i]==vector2[i]) match++;         // Incrementa o acumulador de matches
    else break;                                 // Quebra o laço quando encontrar qualquer diferença
    }
if(match==length) return(1);                    // Vetores idênticos
else return(0);
}
/********************************************/

/*********************************************************************************/
/* Função:    avg_vector
   Descrição: Calcula a média de um vetor de inteiros
   Entrada:   int* vector           - vetor de inteiros
              int length            - comprimento do vetor
   Saída:     double                - média do vetor */
/*********************************************************************************/
double avg_vector(int* vector, int length)
{
int i = 0, sum = 0;
for(i=0;i<length;i++) sum = sum + vector[i];
return((sum*1.0)/(length*1.0));
}
/********************************************/

/*********************************************************************************/
/* Função:    get_serial_data
   Descrição: Captura um pacote de 16 dados da entrada serial
   Entrada:   -
   Saída:     int*                      - vetor contendo os 16 dados da entrada serial */
/*********************************************************************************/
int* get_serial_data(void)
{
unsigned int i = 0;
int* serial_data = (int*)(malloc(NUMBER_OF_INPUTS*sizeof(int)));
bit_clear(GPIO2_DATAOUT,PL);                                    // Carrega as entradas paralelamente
bit_set(GPIO2_DATAOUT,PL);                                      // Desabilita o carregamento de entradas paralelas
serial_data[0] = (int)(bit_read(GPIO2_DATAIN,SD));              // Captura o dado de saída do carregamento paralelo
bit_clear(GPIO2_DATAOUT,CP);                                    // Garante sinal de clock em zero (já é garantido pelo bootloader)
for(i=1;i<NUMBER_OF_INPUTS;i++)
    {
    bit_set(GPIO2_DATAOUT,CP);                                  // Pulso positivo de clock
    bit_clear(GPIO2_DATAOUT,CP);                                // Pulso negativo de clock
    serial_data[i] = (int)(bit_read(GPIO2_DATAIN,SD));          // Captura o dado de saída do carregamento serial
    }
return(serial_data);
}
/********************************************/

/*********************************************************************************/
/* Função:    get_change
   Descrição: Captura uma mudança nos dados seriais
   Entrada:   int*  current_serial_data - ponteiro para o vetor de dados seriais atual
              int*  last_serial_data    - ponteiro para o vetor de dados seriais anterior
   Saída:     int              0:       - nenhuma mudança
                               1:       - houve mudança */
/*********************************************************************************/
int get_change(int* current_serial_data, int* last_serial_data)
{
return(!compare_vector(last_serial_data,current_serial_data,NUMBER_OF_INPUTS));
}
/********************************************/

/*********************************************************************************/
/* Função:    get_sweep_change
   Descrição: Captura uma mudança nos dados seriais relativos ao giro dos encoders
   Entrada:   int*  current_serial_data - ponteiro para o vetor de dados seriais atual
              int*  last_serial_data    - ponteiro para o vetor de dados seriais anterior
   Saída:     int              0:       - nenhuma mudança
                               1:       - houve mudança */
/*********************************************************************************/
int get_sweep_change(int* current_serial_data, int* last_serial_data)
{
return(!compare_vector(current_serial_data,last_serial_data,(NUMBER_OF_INPUTS/2)));
}
/********************************************/

/*********************************************************************************/
/* Função:    get_click
   Descrição: Captura o sinal de click do encoder
   Entrada:   int   encoder             - encoder a ser determinado o sinal de click
              int*  serial_data         - ponteiro para o vetor de dados seriais
   Saída:     int              0:       - sinal de click = 0
                               1:       - sinal de click = 1 */
/*********************************************************************************/
int get_click(int encoder, int* serial_data)
{
int click = 0;
switch(encoder)
    {
    case 1:
        click = !serial_data[ENC1_SW];
        break;
    case 2:
        click = !serial_data[ENC2_SW];
        break;
    case 3:
        click = !serial_data[ENC3_SW];
        break;
    case 4:
        click = !serial_data[ENC4_SW];
        break;
    }
return(click);
}
/********************************************/

/*********************************************************************************/
/* Função:    get_state
   Descrição: Captura em qual estado da tabela verdade os sinais do encoders se encontram
   Entrada:   int*  serial_data         - ponteiro para o vetor de dados seriais
              int   encoder             - encoder a ser determinado o estado
   Saída:     int   0, 1, 2, 3:         - estados válidos da tabela verdade
                             4:         - estado inválido da tabela verdade */
/*********************************************************************************/
int get_state(int* serial_data, int encoder)
{
int state = 4;
switch(encoder)
    {
    case 1:
        if((serial_data[ENC1_A]==0)&&(serial_data[ENC1_B]==0)) state = 0;
        else if((serial_data[ENC1_A]==0)&&(serial_data[ENC1_B]==1)) state = 1;
        else if((serial_data[ENC1_A]==1)&&(serial_data[ENC1_B]==1)) state = 3;
        else if((serial_data[ENC1_A]==1)&&(serial_data[ENC1_B]==0)) state = 2;
        break;
    case 2:
        if((serial_data[ENC2_A]==0)&&(serial_data[ENC2_B]==0)) state = 0;
        else if((serial_data[ENC2_A]==0)&&(serial_data[ENC2_B]==1)) state = 1;
        else if((serial_data[ENC2_A]==1)&&(serial_data[ENC2_B]==1)) state = 3;
        else if((serial_data[ENC2_A]==1)&&(serial_data[ENC2_B]==0)) state = 2;
        break;
    case 3:
        if((serial_data[ENC3_A]==0)&&(serial_data[ENC3_B]==0)) state = 0;
        else if((serial_data[ENC3_A]==0)&&(serial_data[ENC3_B]==1)) state = 1;
        else if((serial_data[ENC3_A]==1)&&(serial_data[ENC3_B]==1)) state = 3;
        else if((serial_data[ENC3_A]==1)&&(serial_data[ENC3_B]==0)) state = 2;
        break;
    case 4:
        if((serial_data[ENC4_A]==0)&&(serial_data[ENC4_B]==0)) state = 0;
        else if((serial_data[ENC4_A]==0)&&(serial_data[ENC4_B]==1)) state = 1;
        else if((serial_data[ENC4_A]==1)&&(serial_data[ENC4_B]==1)) state = 3;
        else if((serial_data[ENC4_A]==1)&&(serial_data[ENC4_B]==0)) state = 2;
        break;
    }
return(state);
}
/********************************************/

/*********************************************************************************/
/* Função:    get_direction
   Descrição: Captura o sentido de giro do encoder
   Entrada:   int   encoder             - encoder a ser determinado o sentido de giro
              int*  current_serial_data - ponteiro para o vetor de dados seriais atual
              int*  last_serial_data    - ponteiro para o vetor de dados seriais anterior
   Saída:     int             -1:       - sentido anti-horário
                               1:       - sentido horário
                               0:       - sentido nenhum */
/*********************************************************************************/
int get_direction(int encoder, int* current_serial_data, int* last_serial_data)
{
int direction = 0, last_state = 4, current_state = 4;
last_state = get_state(last_serial_data, encoder);
current_state = get_state(current_serial_data, encoder);
if(((last_state==0)&&(current_state==1))||((last_state==1)&&(current_state==3))||((last_state==3)&&(current_state==2))||((last_state==2)&&(current_state==0))) direction = 1;
else if(((last_state==0)&&(current_state==2))||((last_state==2)&&(current_state==3))||((last_state==3)&&(current_state==1))||((last_state==1)&&(current_state==0))) direction = -1;
return(direction);
}
/********************************************/

/*********************************************************************************/
/* Função:    get_smooth_direction
   Descrição: Captura o sentido de giro do encoder, utilizando artifício de média
   Entrada:   int*  vector              - vetor de direções do encoder
              int   length              - comprimento do vetor de direções do encoder
   Saída:     int             -1:       - sentido anti-horário
                               1:       - sentido horário
                               0:       - sentido nenhum */
/*********************************************************************************/
int get_smooth_direction(int* vector, int length)
{
int direction = 0;
if(avg_vector(vector,length)>=THRESHOLD) direction = 1;
else if(avg_vector(vector,length)<=(-THRESHOLD)) direction = -1;
return(direction);
}
/********************************************/
