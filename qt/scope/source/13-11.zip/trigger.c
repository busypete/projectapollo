#include "encoder.h"
#include "addres_table.h"
#include "/home/bruno/ti-processor-sdk-linux-am335x-evm-04.02.00.09/linux-devkit/sysroots/armv7ahf-neon-linux-gnueabi/usr/include/stdlib.h"


/*********************************************************************************/
/*  Função:     trigger_detect
    Descrição:  Detecta um evento de trigger.
    Entrada:    double first_value    - primeiro valor de comparação
                double second_value   - segundo valor de comparação
                double trigger_level  - limiar para detectar evento de trigger
                int i                 - índice de iteração atual do vetor de onde foi extraído first_value e second_value
                int number_of_points  - número de pontos do vetor de onde foi extraído first_value e second_value
                char edge             - 'r': borda de subida
                                      - 'f': borda de descida
                                      - 'b': ambas as bordas
                                      - 'a': *ADDR = *ADDR & content
                                      - 'x': *ADDR = *ADDR ^ content
    Saída:      int                   - 0:   evento de trigger não detectado
                                      - < 0: offset negativo
                                      - > 0: offset positivo */
/*********************************************************************************/
int trigger_detect(double first_value, double second_value, double trigger_level, int i, int number_of_points, char edge)
{
int offset = 0;
switch(edge)
    {
    case 'r':
        if((first_value<trigger_level)&&(second_value>trigger_level)) offset = i - number_of_points/2;
        break;
    case 'f':
        if((first_value>trigger_level)&&(second_value<trigger_level)) offset = i - number_of_points/2;
        break;
    case 'b':
        if(((first_value<trigger_level)&&(second_value>trigger_level))||((first_value>trigger_level)&&(second_value<trigger_level))) offset = i - number_of_points/2;
        break;
    }
return(offset);
}
