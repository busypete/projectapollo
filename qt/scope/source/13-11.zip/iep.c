#include "addres_table.h"
#include "frame_table.h"
#include "/home/bruno/ti-processor-sdk-linux-am335x-evm-04.02.00.09/linux-devkit/sysroots/armv7ahf-neon-linux-gnueabi/usr/include/stdlib.h"

#define IEP_CLK         200000000               // Fonte de clock do TIMER IEP (200 MHz)

extern unsigned int memory(unsigned int ADDR, char acess, unsigned int content, char logic);

/*********************************************************************************/
/* Função:    set_sample_rate
   Descrição: Seta a frequência de amostragem do sistema
   Entrada:   double time_div       - tamanho da janela em segundos
   Saída:     int                   - sample rate atual (após a execução da rotina) */
/*********************************************************************************/
int set_sample_rate(double time_div)
{
int freq = (int)((POINTS_PER_FRAME*1.0)/(time_div));
if(freq>MAX_SAMPLE_RATE) freq = MAX_SAMPLE_RATE;
memory(IEP_TMR_CMP0,'w',(unsigned int)((IEP_CLK)/(2*freq)),'k');
return(freq);
}
/********************************************/
