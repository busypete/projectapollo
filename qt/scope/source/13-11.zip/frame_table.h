// Controle do frame
#define QTBUSY              0xCC                                // Qt ocupado
#define QTLAZY              0xDD                                // Qt livre

// Dimensões do frame
#define BUFFER_SIZE         960                                 // Número de amostras no buffer de conversão
#define PACK_SIZE           60                                  // Número de amostras capturadas a cada iteração de data_tick
#define PANEL_WIDTH         480                                 // Largura do display em pixels
#define POINTS_PER_PIXEL    4                                   // Pontos pintados por pixel
#define POINTS_PER_FRAME    PANEL_WIDTH*POINTS_PER_PIXEL        // Pontos pintador por frame

// Parâmetros de desempenho
#define MAX_SAMPLE_RATE     300000                              // Máxima frequência de amostragem por canal
#define FRAME_RATE          25                                  // Frequência de atualização do frame

// Eixo X
#define MAG_X_MAX           0.1024                              // Magntidude máxima, em segundos, do eixo X
#define MAG_X_MIN           0.0004                              // Magnituda mínima, em segundos, do eixo X
#define MAG_X_DEFAULT       0.0008                              // Magnitude padrão do eixo Y
#define MAG_X_FACTOR        2                                   // Fator pelo qual a magnitude do eixo X é manipulada

// Eixo Y
#define MAG_Y_MAX           200                                 // Valor máximo, em volts, do eixo Y
#define MAG_Y_MIN           0.02                                // Valor mínimo, em volts, do eixo Y
#define MAG_Y_DEFAULT       3                                   // Valor padrão do eixo Y
#define MAG_Y_MAG           2                                   // Razão pela qual o eixo Y é multiplicado ou dividido
#define POS_Y_MAX           10                                  // Posição vertical máxima do eixo Y
#define POS_Y_MIN           -10                                 // Posição vertical mínima do eixo Y
#define POS_Y_DEFAULT       0                                   // Posição vertical padrão do eixo Y
#define POS_Y_INC           1                                   // Incremento na posição vertical do eixo Y


