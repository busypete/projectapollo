// Controle do frame
#define QTBUSY              0xCC                                // Qt ocupado
#define QTLAZY              0xDD                                // Qt livre

// Dimensões do frame
#define SAMPLE_PER_PERIOD   12                                  // Número de amostras por período
#define PERIOD_PER_FRAME    10                                  // Número de períodos por frame (será uma função de TIME/DIV)
#define FRAME_SIZE          SAMPLE_PER_PERIOD*PERIOD_PER_FRAME  // Número de amostras por frame

// Parâmetros de desempenho
#define SAMPLE_RATE         180000                              // Frequência de amostragem do sinal de entrada
#define FRAME_RATE          16                                  // Frequência de atualização do frame

// Eixo X
#define AXIS_X_MAX          1                                   // Valor máximo, em segundos, do eixo X
#define AXIS_X_MIN          0.000001                            // Valor mínimo, em segundos, do eixo X
#define X_MAG               2                                   // Razão pela qual o eixo X é multiplicado ou dividido

// Eixo Y
#define AXIS_Y_MAX          200                                 // Valor máximo, em volts, do eixo Y
#define AXIS_Y_MIN          0.02                                // Valor mínimo, em volts, do eixo Y
#define Y_MAG               2                                   // Razão pela qual o eixo Y é multiplicado ou dividido
