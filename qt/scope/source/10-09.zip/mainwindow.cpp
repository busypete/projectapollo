#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "frame_table.h"

#include <QTimer>
#include <QtMath>
#include "QtCharts"
using namespace QtCharts;

extern QLineSeries *ch1;
extern QLineSeries *ch2;

// File
extern "C" void print_channel_to_file(int* vector1, int* vector2, unsigned int data_length, unsigned int sample_rate, const char* filename, const char* mode);
/********************************************/


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Timer
    QTimer *tick = new QTimer(this);
    connect(tick, SIGNAL(timeout()),this, SLOT(tick_timeout()));
    tick->stop();
    tick->start(8);

    // Chart
    ui->chart = new QChart();
    ui->chart->addSeries(ch1);
    ui->chart->addSeries(ch2);
    ui->chart->setTheme(QChart::ChartThemeDark);
    ch1->setColor("yellow");
    ch2->setColor("blue");
    ch1->setName("CH1");
    ch2->setName("CH2");
    ui->chart->createDefaultAxes();
    ui->chart->axisX()->setTitleText("Time (s)");
    ui->chart->axisY()->setTitleText("Voltage (V)");

    // ChartView
    ui->chartView = new QChartView(ui->chart,ui->centralWidget);
    ui->chartView->setGeometry(QRect(0,0,800,480));
    ui->chartView->setRenderHint(QPainter::Antialiasing);
    ui->chartView->show();

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::tick_timeout()
{
// Generate random data
int i;
float* time = static_cast<float*>(malloc(FRAME_SIZE*sizeof(float)));
float* voltage1 = static_cast<float*>(malloc(FRAME_SIZE*sizeof(float)));
float* voltage2 = static_cast<float*>(malloc(FRAME_SIZE*sizeof(float)));

static int j = 0;
ch1->clear();
ch2->clear();
for(i=0;i<FRAME_SIZE;i++)
    {
    time[i] = ((1.0f*i)/(SAMPLE_RATE*1.0f));
    if(j<=2)
        {
        voltage1[i] = static_cast<float>(2*qSin(2.0*M_PI*16.667*static_cast<double>(time[i])-M_PI/2));
        voltage2[i] = static_cast<float>(2*qSin(2.0*M_PI*16.667*static_cast<double>(time[i])+M_PI/2));
        }
    else if(j<=4)
        {
        voltage2[i] = static_cast<float>(2*qSin(2.0*M_PI*16.667*static_cast<double>(time[i])-M_PI/2));
        voltage1[i] = static_cast<float>(2*qSin(2.0*M_PI*16.667*static_cast<double>(time[i])+M_PI/2));
        }
    else j = 0;
    ch1->append(static_cast<double>(time[i]),static_cast<double>(voltage1[i]));
    ch2->append(static_cast<double>(time[i]),static_cast<double>(voltage2[i]));
    }

// Chart update
ui->chart->axisX()->setRange(0,time[FRAME_SIZE-1]);
ui->chart->axisY()->setRange(-3,3);
j++;
}
