#include <QMainWindow>
#include "QtCharts"

namespace Ui {
class MyMainWindow;
}

using namespace QtCharts;

class MyMainWindow : public QMainWindow
{
    Q_OBJECT

private:
    QVector<QPointF>* raw_data1;
    QVector<QPointF>* raw_data2;
    QVector<QPointF>* nice_data1;
    QVector<QPointF>* nice_data2;
    QLineSeries* ch1;
    QLineSeries* ch2;
    QChart* chart;
    QChartView* chartView;
    QTimer* frame_tick;
    QTimer* data_tick;
    QTimer* encoder_tick;

public:
    explicit MyMainWindow(QWidget *parent = nullptr);
    ~MyMainWindow();

private slots:
    void frame_tick_timeout();
    void data_tick_timeout();
    void encoder_tick_timeout();

private:
    Ui::MyMainWindow* ui;
};
