﻿#include "mymainwindow.h"
#include "ui_mainwindow.h"

#include "frame_table.h"
#include "addres_table.h"
#include "encoder.h"
#include "trigger.h"

// Global variables
static int sample_rate = MAX_SAMPLE_RATE;
static int raw_update_request1 = 0, nice_update_request1 = 0, raw_update_request2 = 0, nice_update_request2 = 0;
static double time_div = static_cast<double>(MAG_X_DEFAULT), vertical_position = static_cast<double>(POS_Y_DEFAULT);

// Memory
extern "C" unsigned int memory(unsigned int ADDR, char acess, unsigned int content, char logic);
extern "C" void bit_toggle(unsigned int ADDR, unsigned int x);
/********************************************/

// Encoder
extern "C" int* get_serial_data(void);
extern "C" int get_change(int* current_serial_data, int* last_serial_data);
extern "C" int get_sweep_change(int* current_serial_data, int* last_serial_data);
extern "C" int get_click(int encoder, int* serial_data);
extern "C" int get_direction(int encoder, int* current_serial_data, int* last_serial_data);
extern "C" int get_smooth_direction(int* vector, int length);
/********************************************/

// IEP
extern "C" int set_sample_rate(double time_div);
/********************************************/

// Trigger
extern "C" int trigger_detect(double first_value, double second_value, double trigger_level, int i, int number_of_points, char edge);
/********************************************/


MyMainWindow::MyMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MyMainWindow)
{
    ui->setupUi(this);
    sample_rate = set_sample_rate(time_div);

    // Timer initialization
    frame_tick = new QTimer(this);
    frame_tick->setTimerType(Qt::PreciseTimer);
    connect(frame_tick, SIGNAL(timeout()),this, SLOT(frame_tick_timeout()));
    frame_tick->stop();

    data_tick = new QTimer(this);
    data_tick->setTimerType(Qt::PreciseTimer);
    connect(data_tick, SIGNAL(timeout()),this, SLOT(data_tick_timeout()));
    data_tick->stop();

    encoder_tick = new QTimer(this);
    encoder_tick->setTimerType(Qt::PreciseTimer);
    connect(encoder_tick, SIGNAL(timeout()),this, SLOT(encoder_tick_timeout()));
    encoder_tick->stop();

    // QVector
    raw_data1 = new QVector<QPointF>();
    raw_data2 = new QVector<QPointF>();
    nice_data1 = new QVector<QPointF>(POINTS_PER_FRAME);
    nice_data2 = new QVector<QPointF>(POINTS_PER_FRAME);

    // LineSeries
    ch1 = new QLineSeries(nullptr);
    ch2 = new QLineSeries(nullptr);

    // Chart
    chart = new QChart(nullptr,Qt::Widget);
    chart->setTheme(QChart::ChartThemeDark);
    chart->addSeries(ch1);
    ch1->setColor("yellow");
    ch1->setName("CH1");
    chart->addSeries(ch2);
    ch2->setColor("blue");
    ch2->setName("CH2");
    chart->createDefaultAxes();
    chart->axisX()->setTitleText("Time (s)");
    chart->axisX()->setRange(0,MAG_X_DEFAULT);
    chart->axisY()->setTitleText("Voltage (V)");
    chart->axisY()->setRange(-MAG_Y_DEFAULT,MAG_Y_DEFAULT);

    // ChartView
    chartView = new QChartView(chart,ui->centralWidget);
    chartView->setGeometry(QRect(0,0,800,480));
    chartView->setRenderHint(QPainter::Antialiasing,true);

    // Timer triggering
    frame_tick->start(1000/FRAME_RATE);
    data_tick->start(0);
    encoder_tick->start(1000/ENCODER_RATE);

}

MyMainWindow::~MyMainWindow()
{
    delete ui;
}

void MyMainWindow::frame_tick_timeout()
{
if(raw_update_request1)
    {
    ch1->replace(*raw_data1);
    raw_data1->clear();
    raw_data2->clear();
    raw_update_request1 = 0;
    }
else if(nice_update_request1)
    {
    ch1->replace(*nice_data1);
    raw_data1->clear();
    raw_data2->clear();
    nice_update_request1 = 0;
    }
if(raw_update_request2)
    {
    ch2->replace(*raw_data2);
    raw_data1->clear();
    raw_data2->clear();
    raw_update_request2 = 0;
    }
else if(nice_update_request2)
    {
    ch2->replace(*nice_data2);
    raw_data1->clear();
    raw_data2->clear();
    nice_update_request2 = 0;
    }
}

void MyMainWindow::data_tick_timeout()
{
// Variables
double* voltage1 = new double[PACK_SIZE];
double* voltage2 = new double[PACK_SIZE];
double* time_vector = new double[PACK_SIZE];

static double last_time = 0;
int i = 0, j = 0;
int direction = 0, trigger_busy = 1, number_of_searches = 0, triggered1 = 0, triggered2 = 0;
int offset1 = 0, offset2 = 0, begin = 0, end = 0, number_of_total_points = 0, number_of_window_points = 0;
static int number_of_samples = 0;

if((raw_update_request1==0)&&(nice_update_request1==0)&&(raw_update_request2==0)&&(nice_update_request2==0))
    {
    // Qt busy
    memory(CONTROL_BUFFER,'w',QTBUSY,'k');

    // Capture data
    for(i=0;i<PACK_SIZE;i++)
        {
        time_vector[i] = last_time + ((i*1.0)/(sample_rate*1.0));
        voltage1[i] = (memory(ARM1_BUFFERA+4*static_cast<unsigned int>(i+number_of_samples),'r',0x00,'o')*1.8)/(4096.0) + vertical_position;
        voltage2[i] = 1.5*qSin(2.0*M_PI*1000*(time_vector[i])) + vertical_position;
        *raw_data1 << QPointF(time_vector[i],voltage1[i]);
        *raw_data2 << QPointF(time_vector[i],voltage2[i]);
        }
    delete[] voltage1;
    delete[] voltage2;

    // Qt lazy
    number_of_samples = number_of_samples + PACK_SIZE;
    if(number_of_samples>=BUFFER_SIZE)
        {
        memory(CONTROL_BUFFER,'w',QTLAZY,'k');
        number_of_samples = 0;
        }

    // Update series
    last_time = time_vector[PACK_SIZE-1];
    delete[] time_vector;
    if(last_time>=(OVERSHOOT*time_div))
        {
        // Trigger system
        number_of_total_points = static_cast<int>(OVERSHOOT*time_div*sample_rate);
        number_of_window_points = static_cast<int>(time_div*sample_rate);
        begin = number_of_total_points/2 - number_of_window_points/2;
        end = number_of_total_points/2 + number_of_window_points/2;
        i = number_of_total_points/2;
        do
            {
            offset1 = trigger_detect(raw_data1->at(i-1).y(),raw_data1->at(i).y(),TRIGGER_LEVEL1,i,number_of_total_points,'r');
            offset2 = trigger_detect(raw_data2->at(i-1).y(),raw_data2->at(i).y(),TRIGGER_LEVEL2,i,number_of_total_points,'r');
            if(offset1||offset2)
                {
                if(offset1>0)
                    {
                    if((end-1+offset1)<(raw_data1->size()))
                        {
                        triggered1 = 1;
                        for(j=begin;j<end;j++) (*nice_data1)[j-begin] = QPointF(((j-begin)*1.0)/(sample_rate*1.0),raw_data1->at(j+offset1).y());
                        }
                    }
                else if(offset1<0)
                    {
                    offset1 = -offset1;
                    if((begin-offset1)>=0)
                        {
                        triggered1 = 1;
                        for(j=begin;j<end;j++) (*nice_data1)[j-begin] = QPointF(((j-begin)*1.0)/(sample_rate*1.0),raw_data1->at(j-offset1).y());
                        }
                    }
                if(offset2>0)
                    {
                    if((end-1+offset2)<(raw_data2->size()))
                        {
                        triggered2 = 1;
                        for(j=begin;j<end;j++) (*nice_data2)[j-begin] = QPointF(((j-begin)*1.0)/(sample_rate*1.0),raw_data2->at(j+offset2).y());
                        }
                    }
                else if(offset2<0)
                    {
                    offset2 = -offset2;
                    if((begin-offset2)>=0)
                        {
                        triggered2 = 1;
                        for(j=begin;j<end;j++) (*nice_data2)[j-begin] = QPointF(((j-begin)*1.0)/(sample_rate*1.0),raw_data2->at(j-offset2).y());
                        }
                    }
                trigger_busy = 0;
                }
            else
                {
                if(direction) direction = 0;
                else direction = 1;
                if(direction)
                    {
                    if(number_of_searches<(number_of_total_points/2 - 1)) number_of_searches++;
                    else break;
                    i = number_of_total_points/2 + number_of_searches;
                    }
                else i = number_of_total_points/2 - number_of_searches;
                }
            }
        while(trigger_busy);

        // Update flags
        if(triggered1) nice_update_request1 = 1;
        else raw_update_request1 = 1;
        if(triggered2)  nice_update_request2 = 1;
        else raw_update_request2 = 1;
        last_time = 0;
        }
    }
}

void MyMainWindow::encoder_tick_timeout()
{
static int number_of_serial_captures = 0, number_of_direction_samples = 0;
int j = 0;
static double volt_div = static_cast<double>(MAG_Y_DEFAULT);
static int* last_serial_data = static_cast<int*>((malloc(NUMBER_OF_INPUTS*sizeof(int))));
static int* current_serial_data = static_cast<int*>((malloc(NUMBER_OF_INPUTS*sizeof(int))));
static int* direction1 = static_cast<int*>((malloc(NUMBER_OF_AVG*sizeof(int))));
static int* direction2 = static_cast<int*>((malloc(NUMBER_OF_AVG*sizeof(int))));
static int* direction3 = static_cast<int*>((malloc(NUMBER_OF_AVG*sizeof(int))));
static int* direction4 = static_cast<int*>((malloc(NUMBER_OF_AVG*sizeof(int))));

if(number_of_serial_captures>=2)
    {
    if(get_change(current_serial_data,last_serial_data))
        {
        if(get_sweep_change(current_serial_data,last_serial_data))
            {
            direction1[number_of_direction_samples] = get_direction(1,current_serial_data,last_serial_data);
            direction2[number_of_direction_samples] = get_direction(2,current_serial_data,last_serial_data);
            direction3[number_of_direction_samples] = get_direction(3,current_serial_data,last_serial_data);
            direction4[number_of_direction_samples] = get_direction(4,current_serial_data,last_serial_data);
            number_of_direction_samples++;
            if(number_of_direction_samples>=NUMBER_OF_AVG)
                {
                number_of_direction_samples = 0;
                if(get_smooth_direction(direction1,NUMBER_OF_AVG)==-1)
                    {
                    if(time_div<=((MAG_X_MAX*1.0)/(MAG_X_FACTOR*1.0))) time_div = time_div*MAG_X_FACTOR;
                    else time_div = MAG_X_MAX;
                    chart->axisX()->setRange(0,time_div);
                    sample_rate = set_sample_rate(time_div);
                    }
                else if(get_smooth_direction(direction1,NUMBER_OF_AVG)==1)
                    {
                    if(time_div>=(MAG_X_MIN*MAG_X_FACTOR)) time_div = time_div/(MAG_X_FACTOR*1.0);
                    else time_div = MAG_X_MIN;
                    chart->axisX()->setRange(0,time_div);
                    sample_rate = set_sample_rate(time_div);
                    }
                if(get_smooth_direction(direction2,NUMBER_OF_AVG)==-1)
                    {
                    if(volt_div<=((MAG_Y_MAX*1.0)/(MAG_Y_MAG*1.0))) volt_div = volt_div*MAG_Y_MAG;
                    else volt_div = MAG_Y_MAX;
                    chart->axisY()->setRange(-volt_div,volt_div);
                    }
                else if(get_smooth_direction(direction2,NUMBER_OF_AVG)==1)
                    {
                    if(volt_div>=(MAG_Y_MIN*MAG_Y_MAG)) volt_div = volt_div/(MAG_Y_MAG*1.0);
                    else volt_div = MAG_Y_MIN;
                    chart->axisY()->setRange(-volt_div,volt_div);
                    }
                if(get_smooth_direction(direction3,NUMBER_OF_AVG)==-1)
                    {
                    if(vertical_position>=((POS_Y_MIN+POS_Y_INC)*1.0)) vertical_position = vertical_position - POS_Y_INC*1.0;
                    else vertical_position = POS_Y_MIN;
                    }
                else if(get_smooth_direction(direction3,NUMBER_OF_AVG)==1)
                    {
                    if(vertical_position<=((POS_Y_MAX-POS_Y_INC)*1.0)) vertical_position = vertical_position + POS_Y_INC*1.0;
                    else vertical_position = POS_Y_MAX;
                    }
                }
            }
        else
            {
            number_of_direction_samples = 0;
            }
        }    
    }
else number_of_serial_captures++;
for(j=0;j<NUMBER_OF_INPUTS;j++) last_serial_data[j] = current_serial_data[j];
free(current_serial_data);
current_serial_data = get_serial_data();
}

