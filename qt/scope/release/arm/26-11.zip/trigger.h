// Sistema de trigger
#define TRIGGER_LEVEL1      0.17                                // Limiar de disparo por borda, em volts, do canal 1
#define TRIGGER_LEVEL2      20                                  // Limiar de disparo por borda, em volts, do canal 2
#define OVERSHOOT           1.5                                 // Fator pelo qual o número de pontos usual é multiplicado
                                                                // de forma a existir uma folga para o deslocamento

